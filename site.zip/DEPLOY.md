> **当前临时部署：** <https://gauge-viii-pounds-conclude.trycloudflare.com>  
> 这是 Cloudflare Quick Tunnel，依赖当前电脑与进程；关机/断网/重启后会失效。长期使用请按本文绑定 Cloudflare Pages + Supabase，或使用固定 VPS。
> `server.py` 已内置邮箱注册/登录和 `/api/progress` 进度同步接口。

# 部署成「随时随地、任意设备登录」的网站

当前版本是纯静态站点，进度存在浏览器 `localStorage`，所以换设备不会自动同步。  
要变成“有账号、可登录、跨设备同步”，推荐下面这套最省事的组合：

> **Cloudflare Pages（托管网站） + Supabase（登录 + 数据库） + 自定义域名 + HTTPS**

不想用海外服务，也可以换成 **VPS + Docker + Nginx + Supabase 自建/云数据库**，文末给出方案。

---

## 最快路径：GitHub 上传一个 zip，Render 解压运行

你的仓库已经建好：`https://github.com/sangcuo891-beep/jnu432-site`

### 1. 上传 `site.zip`

1. 打开仓库页面；
2. 点 **Add file → Upload files**（或地址后加 `/upload/main`）；
3. 把 `D:\dsh\site.zip` 拖进去；
4. Commit changes。

> `site.zip` 里已经包含 `index.html`、`server.py`、`assets/`、`requirements.txt`。  
> 不要上传 `data/app.db`。

### 2. Render 创建 Web Service

1. 打开 <https://render.com>，用 GitHub 登录；
2. **New → Web Service**；
3. 选择 `jnu432-site` 仓库；
4. 配置：
   - Runtime：`Python 3`
   - Build Command：
     ```bash
     python -c "import zipfile; zipfile.ZipFile('site.zip').extractall('.')"
     ```
   - Start Command：
     ```bash
     python server.py
     ```
5. 环境变量：
   - `DEEPSEEK_API_KEY` = 你的 Key（可选）
   - `HOST` = `0.0.0.0`（必须，Render 需要对外监听）
   - `PORT` 由 Render 自动提供，`server.py` 会读取。
6. 点 **Create Web Service**。

部署完成后会得到：

```text
https://jnu432-site.onrender.com
```

手机、电脑、平板都能打开；注册邮箱账号后，做题/背诵/模拟卷进度会同步。

### 3. 数据持久化（重要）

Render 免费实例的文件系统是临时的，重启/重新部署后 SQLite 账号数据可能丢失。  
要长期保存，给 Web Service 加一个 **Disk**：

- Mount Path：`/app/data`
- Size：1GB（付费）

或者改用 Supabase/Postgres（见下文）。

### 4. 自定义域名

Render → Settings → Custom Domain，添加域名，按提示到域名服务商加 CNAME，开启 HTTPS。

---

## 一、目标架构

```
浏览器（手机/电脑/平板）
   │  HTTPS
   ▼
Cloudflare Pages  ── 静态网站（index.html / assets / 原卷图片）
   │
   ├── Supabase Auth      邮箱验证码 / 密码 / Google / 微信 OAuth
   └── Supabase Postgres  用户表、做题记录、背诵进度、模拟卷分数
```

登录后，前端把 `localStorage` 里的进度同步到 Supabase；换设备登录同一账号即可拉回。

---

## 二、把网站部署到 Cloudflare Pages

### 1. 上传代码

在 GitHub 新建仓库，把 `jinan432-site` 目录推上去：

```bash
cd jinan432-site
git init
git add .
git commit -m "jnu432 site"
git branch -M main
git remote add origin https://github.com/你的用户名/jnu432-site.git
git push -u origin main
```

### 2. 连接 Cloudflare Pages

1. 注册/登录 Cloudflare；
2. `Workers & Pages → Create → Pages → Connect to Git`；
3. 选择仓库；
4. Build command 留空，Build output directory 填 `/`；
5. Deploy。

部署后会得到一个 `https://xxx.pages.dev` 地址，手机/电脑都能访问。

### 3. 绑定域名

1. 在 Cloudflare 添加你的域名；
2. Pages → Custom domains → 添加 `www.你的域名.com`；
3. 按提示添加 CNAME；
4. 开启 `Always Use HTTPS`。

> 国内访问 Cloudflare Pages 可能不稳定；如果主要面向国内，建议用阿里云/腾讯云 OSS + CDN + 备案域名，或 VPS。

---

## 三、Supabase：登录 + 跨设备进度

### 1. 创建项目

1. 打开 <https://supabase.com>，新建项目；
2. 记下 `Project URL` 和 `anon public key`；
3. `Authentication → Providers` 开启 Email；
4. 需要微信/Google 登录时，在对应 Provider 里填 OAuth 配置。

### 2. 建表

在 SQL Editor 执行：

```sql
-- 用户资料
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nickname text,
  created_at timestamptz default now()
);

-- 做题记录：一个用户一道题一条
create table public.answers (
  user_id uuid references auth.users(id) on delete cascade,
  question_id text not null,
  status text check (status in ('seen','ok','bad')),
  updated_at timestamptz default now(),
  primary key (user_id, question_id)
);

-- 背诵卡进度
create table public.card_progress (
  user_id uuid references auth.users(id) on delete cascade,
  card_id text not null,
  level int default 0,
  due date,
  last_seen timestamptz,
  primary key (user_id, card_id)
);

-- 模拟卷
create table public.mock_scores (
  user_id uuid references auth.users(id) on delete cascade,
  mock_id text not null,
  score int,
  submitted boolean default false,
  answers jsonb default '{}'::jsonb,
  updated_at timestamptz default now(),
  primary key (user_id, mock_id)
);

-- 打开 RLS：每个用户只能读写自己的数据
alter table public.profiles enable row level security;
alter table public.answers enable row level security;
alter table public.card_progress enable row level security;
alter table public.mock_scores enable row level security;

create policy "own profile" on public.profiles
  for all using (auth.uid() = id) with check (auth.uid() = id);

create policy "own answers" on public.answers
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "own cards" on public.card_progress
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "own mocks" on public.mock_scores
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
```

### 3. 前端接入

在 `index.html` 的 `</body>` 前加入：

```html
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
<script>
  window.supabaseClient = supabase.createClient(
    "https://你的项目.supabase.co",
    "你的 anon public key"
  );
</script>
```

新增一个 `assets/auth.js`（示例）：

```js
const sb = window.supabaseClient;

async function signIn(email) {
  const { error } = await sb.auth.signInWithOtp({ email });
  if (error) alert(error.message);
  else alert("登录链接已发到邮箱，请查收");
}

async function currentUser() {
  const { data } = await sb.auth.getUser();
  return data.user;
}

async function pullProgress() {
  const user = await currentUser();
  if (!user) return null;
  const [answers, cards, mocks] = await Promise.all([
    sb.from("answers").select("*"),
    sb.from("card_progress").select("*"),
    sb.from("mock_scores").select("*")
  ]);
  return { answers: answers.data, cards: cards.data, mocks: mocks.data };
}

async function pushAnswer(questionId, status) {
  const user = await currentUser();
  if (!user) return;
  await sb.from("answers").upsert({
    user_id: user.id, question_id: questionId, status, updated_at: new Date()
  });
}
```

然后把 `app.js` 里的 `save()` 改成：

1. 先写 `localStorage`；
2. 如果已登录，再异步 `upsert` 到 Supabase；
3. 页面打开时先 `pullProgress()`，合并到 `state`。

合并策略建议：

```js
// 同一道题：以 updated_at 较新的为准
// 背诵卡：以 last_seen 较新的为准
// 模拟卷：以 updated_at 较新的为准
```

### 4. 登录页

新增 `login.html` 或在 `#/account` 路由里放：

- 邮箱输入框 + “发送登录链接”；
- 或 email/password 登录/注册；
- 登录成功后显示昵称、退出按钮、同步状态。

Supabase 的 Magic Link 不需要自己发邮件，最省事。

---

## 四、把 AI Key 放到服务端

不要把 DeepSeek Key 写进前端。当前 `server.py` 已经是代理，但 Cloudflare Pages 是纯静态，不能跑 Python。

两种做法：

### 方案 A：Cloudflare Worker 代理

新建 Worker，环境变量 `DEEPSEEK_API_KEY`，代码：

```js
export default {
  async fetch(request, env) {
    if (request.method !== "POST") return new Response("Method Not Allowed", { status: 405 });
    const body = await request.text();
    const res = await fetch("https://api.deepseek.com/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${env.DEEPSEEK_API_KEY}`
      },
      body
    });
    return new Response(res.body, {
      status: res.status,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
    });
  }
};
```

前端 AI 设置的代理地址改为 `https://你的-worker.workers.dev/chat`。

### 方案 B：VPS 上继续用 `server.py`

把 `server.py` 部署到 VPS，用 `systemd`/Docker 常驻，Nginx 反代 + Certbot HTTPS。  
优点：静态站和 AI 代理同一个域名，不用改前端。

---

## 五、VPS 方案（国内访问更稳）

1. 买一台 1C2G 云服务器，安装 Ubuntu 22.04；
2. 安装 Nginx：
   ```bash
   sudo apt update && sudo apt install -y nginx python3
   ```
3. 上传网站到 `/var/www/jnu432`；
4. 用 `server.py` 常驻：
   ```bash
   cd /var/www/jnu432
   export DEEPSEEK_API_KEY="sk-..."
   nohup python3 server.py >/var/log/jnu432.log 2>&1 &
   ```
5. Nginx 配置：
   ```nginx
   server {
     listen 80;
     server_name 你的域名.com;
     location / {
       proxy_pass http://127.0.0.1:8123;
       proxy_set_header Host $host;
     }
   }
   ```
6. 用 Certbot 申请 HTTPS：
   ```bash
   sudo apt install -y certbot python3-certbot-nginx
   sudo certbot --nginx -d 你的域名.com
   ```
7. 域名解析 A 记录指向服务器 IP。

> 国内服务器需要域名备案；不想备案就用香港/新加坡节点，但访问速度可能一般。

---

## 六、登录方式怎么选

| 方式 | 优点 | 缺点 |
|---|---|---|
| 邮箱 Magic Link | 不用记密码，Supabase 自带邮件 | 邮件可能进垃圾箱，国内收信不稳定 |
| 邮箱 + 密码 | 最通用 | 要自己做找回密码 |
| Google OAuth | 体验好 | 国内网络不一定可用 |
| 微信 OAuth | 国内用户方便 | 需要认证服务号/开放平台，配置最麻烦 |

建议先做 **邮箱 + 密码** 或 **邮箱 Magic Link**，跑通跨设备同步；微信登录以后再加。

---

## 七、上线检查清单

- [ ] 手机 4G/5G 能打开 `https://你的域名`
- [ ] 电脑、手机登录同一账号，做题记录能互相同步
- [ ] 退出登录后，看不到别人的数据（RLS 生效）
- [ ] `anon key` 只用于前端；`service_role key` 绝不进前端
- [ ] AI Key 只在服务端环境变量/Worker Secret 里
- [ ] 每日备份 Supabase 数据库
- [ ] 配好自定义域名和 HTTPS
- [ ] 手机端“添加到主屏幕”（PWA）可选：加 `manifest.webmanifest`

---

## 八、最小可行路线（建议）

1. 先把当前静态站部署到 Cloudflare Pages，拿到公网地址；
2. 注册 Supabase，开邮箱登录，建 `answers` / `card_progress` 两张表；
3. 在 `app.js` 的 `save()` 里加一个 `pushProgress()`；
4. 登录后拉取云端数据合并；
5. 最后再把 AI 代理换成 Worker 或 VPS。

这样 1—2 天可以跑通“登录 + 跨设备同步”，不需要重写整个网站。

