﻿(function(){
/* 概率论与数理统计真题库：题干 + 完整解析 */
const R = String.raw;
window.BANK_PROB = [
  {
    id: 'p2011-01', year: 2011, part: '概率', type: '简答', topic: 'pr04', marks: 10,
    title: '独立性与不相关的区别和联系',
    prompt: R`试问独立性与不相关之间的区别与联系？`,
    answer: R`<p><b>定义：</b>若 \(P(X\le x,Y\le y)=P(X\le x)P(Y\le y)\)，称 \(X,Y\) 独立；若 \(\operatorname{Cov}(X,Y)=0\)（等价于 \(\rho_{XY}=0\)），称 \(X,Y\) 不相关。</p>
      <p><b>区别：</b>独立是“没有任何关系”，联合分布可分解；不相关只说明“没有线性关系”，仍可能存在非线性关系。独立 ⇒ 不相关；不相关 ⇏ 独立。</p>
      <p><b>反例：</b>设 \(X\sim U(-1,1)\)，\(Y=X^2\)。则 \(E(X)=0,\ E(XY)=E(X^3)=0\)，故 \(\operatorname{Cov}(X,Y)=0\)，二者不相关；但 \(Y\) 完全由 \(X\) 决定，显然不独立。</p>
      <p><b>联系：</b>在二维正态分布中，不相关与独立等价；一般情形下，独立比不相关更强。</p>
      <div class="final">独立 ⇒ 不相关；不相关 ⇏ 独立；二维正态下二者等价。</div>`,
    tags: ['独立', '不相关', '二维正态']
  },
  {
    id: 'p2011-02', year: 2011, part: '概率', type: '简答', topic: 'pr07', marks: 10,
    title: '极大似然估计及其优点',
    prompt: R`什么是极大似然法估计？它具有哪些优点？`,
    answer: R`<p><b>定义：</b>在参数空间 \(\Theta\) 中，选择使样本观测值出现概率（或密度）最大的参数值作为估计，即</p>
      \[ \hat{\theta}_{MLE}=\arg\max_{\theta\in\Theta}L(\theta),\qquad L(\theta)=\prod_{i=1}^{n}f(x_i;\theta). \]
      <p><b>优点：</b></p>
      <ol>
        <li><b>充分利用样本信息：</b>基于联合密度/似然函数，信息利用充分。</li>
        <li><b>大样本性质好：</b>在正则条件下具有一致性、渐近正态性和渐近有效性。</li>
        <li><b>不变性：</b>若 \(\hat{\theta}\) 是 \(\theta\) 的 MLE，则 \(g(\hat{\theta})\) 是 \(g(\theta)\) 的 MLE。</li>
        <li><b>适用范围广：</b>离散、连续、多参数模型都可使用。</li>
      </ol>
      <p><b>局限：</b>小样本可能有偏；对模型设定敏感；有时似然方程无显式解，需要数值优化。</p>
      <div class="final">MLE=让样本出现概率最大的参数；优点：信息充分、大样本一致/渐近正态/有效、不变性；局限：小样本有偏、依赖模型。</div>`,
    tags: ['极大似然', '估计量评价']
  },
  {
    id: 'p2012-01', year: 2012, part: '概率', type: '计算', topic: 'pr03', marks: 15,
    title: '连续射击的联合分布与边缘分布',
    prompt: R`某人进行连续射击，每次击中目标的概率为 \(p\ (0<p<1)\)。以 \(X,Y\) 分别表示第一次、第二次击中目标时所射击的次数。求：（1）\((X,Y)\) 的联合分布列；（2）\(X\) 与 \(Y\) 的边缘分布。`,
    answer: R`<p>要使第 \(i\) 次首次击中、第 \(j\) 次第二次击中，必须：前 \(i-1\) 次全未中，第 \(i\) 次中；第 \(i+1\) 到 \(j-1\) 次全未中，第 \(j\) 次中。因此 \(1\le i<j\)：</p>
      \[ P(X=i,Y=j)=p(1-p)^{i-1}\cdot p(1-p)^{j-i-1}=p^2(1-p)^{j-2}. \]
      <p><b>边缘分布：</b></p>
      \[ P(X=i)=\sum_{j=i+1}^{\infty}p^2(1-p)^{j-2}=p(1-p)^{i-1},\quad i=1,2,\ldots \]
      即 \(X\) 服从参数为 \(p\) 的几何分布。
      \[ P(Y=j)=\sum_{i=1}^{j-1}p^2(1-p)^{j-2}=(j-1)p^2(1-p)^{j-2},\quad j=2,3,\ldots \]
      即 \(Y\) 是“第二次成功所需次数”，服从负二项分布（帕斯卡分布）。
      <div class="final">联合：\(p^2(1-p)^{j-2}\ (1\le i<j)\)；边缘：\(X\sim Geom(p)\)，\(Y\) 为负二项（第二次成功）。</div>`,
    tags: ['几何分布', '负二项分布', '联合分布列']
  },
  {
    id: 'p2012-02', year: 2012, part: '概率', type: '计算', topic: 'pr08', marks: 15,
    title: '中药治疗高血压的配对 t 检验',
    prompt: R`某医院用中药治疗高血压，记录 50 例治疗前后舒张压之差，均值 16.28，样本标准差 10.58。假定差值服从正态分布，问在 \(\alpha=0.05\) 下该中药是否有效？已知 \(t_{0.05}(49)=1.677\)。`,
    answer: R`<p>设差值 \(D=\text{治疗前}-\text{治疗后}\)，若有效则 \(E(D)>0\)。检验：</p>
      \[ H_0:\mu_D\le0\quad\text{vs}\quad H_1:\mu_D>0. \]
      \[ t=\frac{\bar{d}-0}{s/\sqrt{n}}=\frac{16.28}{10.58/\sqrt{50}}=\frac{16.28}{1.496}=10.88. \]
      <p>拒绝域 \(t>t_{0.05}(49)=1.677\)。因为 \(10.88>1.677\)，拒绝 \(H_0\)。</p>
      <p><b>结论：</b>在 \(\alpha=0.05\) 下，治疗前后舒张压差显著大于 0，说明该中药对高血压治疗有效。</p>
      <div class="final">\(t=10.88>1.677\)，拒绝 \(H_0\)，中药有效。</div>`,
    tags: ['配对t检验', '单侧检验', '医学统计']
  },
  {
    id: 'p2013-01', year: 2013, part: '概率', type: '计算', topic: 'pr06', marks: 20,
    title: '用正态分布构造 χ²、t、F',
    prompt: R`设 \(Z_1,Z_2,Z_3\) 独立同分布于 \(N(0,1)\)。试用它们构造：（1）自由度为 3 的卡方分布；（2）自由度为 2 的 t 分布；（3）F 分布。`,
    answer: R`<p><b>（1）χ²(3)：</b>标准正态的平方和</p>
      \[ \chi^2=Z_1^2+Z_2^2+Z_3^2\sim\chi^2(3). \]
      <p><b>（2）t(2)：</b>一个标准正态除以独立的 \(\sqrt{\chi^2(2)/2}\)：</p>
      \[ T=\frac{Z_3}{\sqrt{(Z_1^2+Z_2^2)/2}}\sim t(2). \]
      <p><b>（3）F 分布：</b>两个独立 χ² 各除自由度再相除：</p>
      \[ F=\frac{Z_1^2/1}{Z_2^2/1}=\frac{Z_1^2}{Z_2^2}\sim F(1,1). \]
      <p><b>说明：</b>构造 t 时分母的 χ² 必须与分子的标准正态独立；构造 F 时两个 χ² 必须独立。</p>
      <div class="final">\(Z_1^2+Z_2^2+Z_3^2\sim\chi^2(3)\)；\(Z_3/\sqrt{(Z_1^2+Z_2^2)/2}\sim t(2)\)；\(Z_1^2/Z_2^2\sim F(1,1)\)。</div>`,
    tags: ['三大分布', '构造', '自由度']
  },
  {
    id: 'p2015-01', year: 2015, part: '概率', type: '计算', topic: 'pr01', marks: 10,
    title: '移球后的全概率与贝叶斯',
    prompt: R`甲箱有 \(a\) 个白球、\(b\) 个红球，乙箱有 \(c\) 个白球、\(d\) 个红球。从甲箱任取 1 球放入乙箱，再从乙箱任取 1 球。求从乙箱取得白球的概率；若已知取得白球，求它来自甲箱白球的概率。`,
    answer: R`<p>设 \(A_1\) 为从甲箱取到白球，\(A_2\) 为取到红球；\(B\) 为从乙箱取到白球。</p>
      \[ P(A_1)=\frac{a}{a+b},\quad P(A_2)=\frac{b}{a+b}. \]
      \[ P(B\mid A_1)=\frac{c+1}{c+d+1},\qquad P(B\mid A_2)=\frac{c}{c+d+1}. \]
      <p><b>全概率：</b></p>
      \[ P(B)=\frac{a}{a+b}\cdot\frac{c+1}{c+d+1}+\frac{b}{a+b}\cdot\frac{c}{c+d+1}. \]
      <p><b>贝叶斯：</b></p>
      \[ P(A_1\mid B)=\frac{\frac{a}{a+b}\cdot\frac{c+1}{c+d+1}}{P(B)}. \]
      <div class="final">\(P(B)=\frac{a(c+1)+bc}{(a+b)(c+d+1)}\)；后验概率按贝叶斯公式计算。</div>`,
    tags: ['全概率', '贝叶斯', '摸球']
  },
  {
    id: 'p2016-01', year: 2016, part: '概率', type: '计算', topic: 'pr08', marks: 20,
    title: '两组学生成绩的 t 检验与样本量问题',
    prompt: R`第一组 10 人，成绩为 100、99、99、100、100、100、100、99、100、99；第二组 2 人，成绩为 50、30。对两组分别作 \(\alpha=0.05\) 的 t 检验：\(H_0:\mu=100,\ H_1:\mu<100\)。你得出什么结论？该结论合理吗？说明理由。已知 \(t_{0.05}(9)=1.833,\ t_{0.05}(1)=6.314\)。`,
    answer: R`<p><b>第一组：</b>\(\bar{x}_1=99.7\)，\(s_1^2=0.1\)，\(s_1=0.3162\)：</p>
      \[ t_1=\frac{99.7-100}{0.3162/\sqrt{10}}=-3.00. \]
      \(t_1<-1.833\)，拒绝 \(H_0\)，认为第一组均值显著低于 100。
      <p><b>第二组：</b>\(\bar{x}_2=40\)，\(s_2=14.142\)：</p>
      \[ t_2=\frac{40-100}{14.142/\sqrt{2}}=-6.00. \]
      \(t_2=-6.00>-6.314\)，不拒绝 \(H_0\)。
      <p><b>结论是否合理：</b>不合理。第二组只有 2 个观测，t 检验的前提（正态总体、样本量足够）不成立，自由度 1 导致临界值极大、功效极低；虽然均值差 60 分，仍无法拒绝。应增大样本量，或用非参数方法/描述性统计，而不能据此认为第二组“与 100 无显著差异”。</p>
      <div class="final">第一组 \(t=-3.00\)，拒绝；第二组 \(t=-6.00\)，不拒绝；第二组 n=2，结论不可靠。</div>`,
    tags: ['t检验', '小样本', '统计功效']
  },
  {
    id: 'p2017-01', year: 2017, part: '概率', type: '计算', topic: 'pr08', marks: 15,
    title: '居民消费支出是否显著增加',
    prompt: R`某地居民某种消费服从正态分布，去年同期均值 135.5 元。今年随机抽取 49 人，月平均 140.5 元，样本标准差 8.5 元。在 \(\alpha=0.05\) 下检验今年与去年相比有无显著增加。已知 \(t_{0.05}(48)=1.677\)。`,
    answer: R`<p>检验 \(H_0:\mu\le135.5\) vs \(H_1:\mu>135.5\)。这是右单侧检验。</p>
      \[ t=\frac{140.5-135.5}{8.5/\sqrt{49}}=\frac{5}{1.2143}=4.118. \]
      <p>拒绝域 \(t>1.677\)。因为 \(4.118>1.677\)，拒绝 \(H_0\)。</p>
      <p><b>结论：</b>在 \(\alpha=0.05\) 下，今年居民该种消费支出显著高于去年。</p>
      <div class="final">\(t=4.118>1.677\)，拒绝 \(H_0\)，显著增加。</div>`,
    tags: ['单侧t检验', '消费支出']
  },
  {
    id: 'p2018-01', year: 2018, part: '概率', type: '计算', topic: 'pr09', marks: 15,
    title: '打电话次数是否服从 Poisson 分布',
    prompt: R`某商业中心 908 人，上班第一小时内打电话次数与人数：0 次 490 人，1 次 334 人，2 次 68 人，3 次 16 人。试检验打电话次数是否服从 Poisson 分布。已知 \(\chi^2_{0.05}(2)=5.991,\ \chi^2_{0.05}(3)=7.815\)。`,
    answer: R`<p>Poisson 分布参数 \(\lambda\) 用样本均值估计：</p>
      \[ \hat{\lambda}=\frac{0\times490+1\times334+2\times68+3\times16}{908}=\frac{518}{908}=0.5705. \]
      <p>计算概率与期望频数：</p>
      \[ p_0=e^{-0.5705}=0.5653,\quad p_1=0.3225,\quad p_2=0.0920,\quad p_{\ge3}=0.0203. \]
      期望频数：\(E=(513.25,\ 292.80,\ 83.52,\ 18.43)\)，观测 \(O=(490,\ 334,\ 68,\ 16)\)。
      \[ \chi^2=\sum\frac{(O_i-E_i)^2}{E_i} =1.054+5.801+2.885+0.320=10.06. \]
      <p>类别数 \(k=4\)，估计 1 个参数，\(df=4-1-1=2\)。临界值 5.991。因为 \(10.06>5.991\)，拒绝“服从 Poisson 分布”的原假设。</p>
      <div class="final">\(\hat{\lambda}=0.5705\)，\(\chi^2=10.06>5.991\)，拒绝 Poisson 分布假设。</div>`,
    tags: ['Poisson分布', '拟合优度', '自由度']
  },
  {
    id: 'p2018-02', year: 2018, part: '概率', type: '计算', topic: 'pr09', marks: 15,
    title: '三个工厂零件强度的单因素方差分析',
    prompt: R`三个工厂生产同种零件，各抽 4 个测强度：甲 103、101、98、110；乙 113、107、108、116；丙 82、92、84、86。问三个工厂零件平均强度是否相同？已知 \(F_{0.05}(2,9)=4.26\)。`,
    answer: R`<p>各组均值：\(\bar{x}_甲=103,\ \bar{x}_乙=111,\ \bar{x}_丙=86\)；总均值 \(\bar{x}=100\)。</p>
      <p><b>组间平方和：</b></p>
      \[ SSA=4[(103-100)^2+(111-100)^2+(86-100)^2]=4(9+121+196)=1304. \]
      <p><b>组内平方和：</b></p>
      \[ SSE=(0^2+(-2)^2+(-5)^2+7^2)+ (2^2+(-4)^2+(-3)^2+5^2)+((-4)^2+6^2+(-2)^2+0^2) \]
      \[ =78+54+56=188. \]
      <p><b>方差分析：</b></p>
      \[ MSB=\frac{1304}{2}=652,\quad MSE=\frac{188}{9}=20.889,\quad F=\frac{652}{20.889}=31.21. \]
      <p>因为 \(31.21>4.26\)，拒绝 \(H_0:\mu_甲=\mu_乙=\mu_丙\)，三个工厂平均强度有显著差异。</p>
      <div class="final">\(F=31.21>4.26\)，拒绝均值相同的原假设。</div>`,
    tags: ['单因素方差分析', 'F检验', '平方和分解']
  },
  {
    id: 'p2020-01', year: 2020, part: '概率', type: '计算', topic: 'pr07', marks: 20,
    title: '均匀分布参数的无偏估计与有效性',
    prompt: R`设总体 \(X\sim U(0,\theta)\)，\(X_1,\ldots,X_n\) 为样本。讨论 \(\hat{\theta}_1=2\bar{X}\)、\(\hat{\theta}_2=\frac{n+1}{n}X_{(n)}\) 是否无偏；若无偏，比较哪一个更有效。`,
    answer: R`<p>\(E(X)=\theta/2\)，故</p>
      \[ E(2\bar{X})=2E(\bar{X})=2\cdot\frac{\theta}{2}=\theta, \]
      \(\hat{\theta}_1\) 无偏。
      <p>最大值 \(X_{(n)}\) 的分布函数 \(F_n(x)=(x/\theta)^n\)，密度 \(f_n(x)=nx^{n-1}/\theta^n\)，故</p>
      \[ E(X_{(n)})=\int_0^\theta x\frac{nx^{n-1}}{\theta^n}\,\mathrm{d}x=\frac{n}{n+1}\theta. \]
      因此 \(E(\hat{\theta}_2)=\frac{n+1}{n}\cdot\frac{n}{n+1}\theta=\theta\)，也无偏。
      <p><b>方差比较：</b></p>
      \[ \operatorname{Var}(2\bar{X})=4\frac{\operatorname{Var}(X)}{n}=4\frac{\theta^2/12}{n}=\frac{\theta^2}{3n}. \]
      \[ \operatorname{Var}(X_{(n)})=\frac{n}{(n+1)^2(n+2)}\theta^2,\qquad \operatorname{Var}(\hat{\theta}_2)=\frac{\theta^2}{n(n+2)}. \]
      因为 \(\frac{1}{n(n+2)}<\frac{1}{3n}\)（n>1），所以 \(\hat{\theta}_2\) 方差更小、更有效。</p>
      <div class="final">二者均无偏；\(\hat{\theta}_2=\frac{n+1}{n}X_{(n)}\) 更有效。</div>`,
    tags: ['无偏性', '有效性', '次序统计量']
  },
  {
    id: 'p2022-01', year: 2022, part: '概率', type: '计算', topic: 'pr03', marks: 20,
    title: 'Poisson 变量的和与条件分布',
    prompt: R`设 \(X\sim P(\lambda)\)、\(Y\sim P(\mu)\) 且相互独立。求：（1）\(Z=X+Y\) 的分布；（2）\(X\mid Z=z\) 的分布。`,
    answer: R`<p><b>（1）卷积：</b>对 \(k=0,1,\ldots\)，</p>
      \[ P(Z=k)=\sum_{i=0}^{k}P(X=i)P(Y=k-i) =\sum_{i=0}^{k}\frac{\lambda^i e^{-\lambda}}{i!}\frac{\mu^{k-i}e^{-\mu}}{(k-i)!}. \]
      \[ =\frac{e^{-(\lambda+\mu)}}{k!}\sum_{i=0}^{k}\binom{k}{i}\lambda^i\mu^{k-i} =\frac{e^{-(\lambda+\mu)}(\lambda+\mu)^k}{k!}. \]
      故 \(Z\sim P(\lambda+\mu)\)。
      <p><b>（2）条件分布：</b></p>
      \[ P(X=i\mid Z=z)=\frac{P(X=i)P(Y=z-i)}{P(Z=z)} =\binom{z}{i}\left(\frac{\lambda}{\lambda+\mu}\right)^i\left(\frac{\mu}{\lambda+\mu}\right)^{z-i}. \]
      故 \(X\mid Z=z\sim B\left(z,\frac{\lambda}{\lambda+\mu}\right)\)。
      <div class="final">\(Z\sim P(\lambda+\mu)\)；\(X\mid Z=z\sim B(z,\lambda/(\lambda+\mu))\)。</div>`,
    tags: ['Poisson分布', '卷积', '条件分布']
  },
  {
    id: 'p2022-02', year: 2022, part: '概率', type: '计算', topic: 'pr07', marks: 20,
    title: '对数正态总体均值的置信区间',
    prompt: R`0.25、0.50、1.25、0.80、2.00、4.00 是来自总体 \(X\) 的样本，已知 \(Y=\ln X\sim N(\mu,\sigma^2)\)。求：（1）\(\mu\) 的 95% 置信区间；（2）\(E(X)\) 的 95% 置信区间。`,
    answer: R`<p>取对数：\(y=(-1.3863,-0.6931,0.2231,-0.2231,0.6931,1.3863)\)。\(\bar{y}=0\)，\(s_y=0.9904\)，\(n=6\)，\(t_{0.025}(5)=2.571\)。</p>
      <p><b>（1）μ 的区间：</b></p>
      \[ 0\pm2.571\frac{0.9904}{\sqrt{6}}=[-1.0395,\ 1.0395]. \]
      <p><b>（2）\(E(X)\)：</b>对数正态的均值 \(E(X)=\exp(\mu+\sigma^2/2)\)。用 \(s_y^2=0.9808\) 估计 \(\sigma^2\)：</p>
      \[ \hat{E}(X)=\exp(0+0.4904)=1.633. \]
      将 μ 的区间端点代入（近似，忽略 σ² 的抽样误差）：
      \[ [\exp(-1.0395+0.4904),\ \exp(1.0395+0.4904)] =[0.577,\ 4.618]. \]
      <div class="final">μ 的 95% CI 约 \([-1.04,1.04]\)；\(E(X)\) 的 95% CI 约 \([0.58,4.62]\)（近似）。</div>`,
    tags: ['对数正态', '置信区间', '变换']
  },
  {
    id: 'p2023-01', year: 2023, part: '概率', type: '计算', topic: 'pr08', marks: 20,
    title: '洗衣粉包装的第二类错误',
    prompt: R`自动生产线包装洗衣粉，标准重量 1000 g，以往标准差 40 g。随机抽取 \(n=100\) 检验，\(\alpha=0.05\)。若真实均值变为 1012 g，求犯第二类错误的概率 \(\beta\)。已知 \(z_{0.05}=1.645\)。`,
    answer: R`<p>右单侧检验 \(H_0:\mu\le1000\) vs \(H_1:\mu>1000\)。拒绝域：</p>
      \[ \bar{X}>1000+1.645\frac{40}{\sqrt{100}}=1000+6.58=1006.58. \]
      <p>当真实 \(\mu=1012\) 时，接受域为 \(\bar{X}\le1006.58\)：</p>
      \[ \beta=P(\bar{X}\le1006.58\mid\mu=1012) =\Phi\left(\frac{1006.58-1012}{40/10}\right) =\Phi(-1.355). \]
      \[ \beta\approx0.0877. \]
      <p>检验功效 \(1-\beta=0.9123\)。</p>
      <div class="final">\(\beta\approx8.77\%\)，功效约 91.23%。</div>`,
    tags: ['第二类错误', '功效', '单侧检验']
  },
  {
    id: 'p2024-01', year: 2024, part: '概率', type: '计算', topic: 'pr03', marks: 15,
    title: '指数变量之和与比例的联合分布',
    prompt: R`设 \(X,Y\) 独立同分布于参数为 1 的指数分布，密度 \(p(x)=e^{-x}\ (x>0)\)。令 \(U=X+Y,\ V=\frac{X}{X+Y}\)。（1）求 \(U\) 的分布函数；（2）求 \(U,V\) 的联合密度 \(p(u,v)\)；（3）判断 \(U,V\) 是否独立。`,
    answer: R`<p><b>（1）U 的分布：</b>两个独立指数变量之和服从 Gamma(2,1)：</p>
      \[ f_U(u)=u e^{-u},\quad u>0;\qquad F_U(u)=1-e^{-u}(1+u),\quad u\ge0. \]
      <p><b>（2）变量变换：</b>\(x=uv,\ y=u(1-v)\)，雅可比 \(J=u\)。联合密度：</p>
      \[ f_{U,V}(u,v)=f_X(uv)f_Y(u(1-v))\,u =e^{-uv}e^{-u(1-v)}u=u e^{-u}, \]
      其中 \(u>0,\ 0<v<1\)。
      <p><b>（3）独立性：</b></p>
      \[ f_U(u)=u e^{-u},\quad f_V(v)=1,\ 0<v<1. \]
      因为 \(f_{U,V}(u,v)=f_U(u)f_V(v)\)，所以 \(U,V\) 独立，且 \(V\sim U(0,1)\)。</p>
      <div class="final">\(U\sim\Gamma(2,1)\)；\(f_{U,V}=u e^{-u}\)（u>0,0<v<1）；U 与 V 独立，V~U(0,1)。</div>`,
    tags: ['指数分布', '变量变换', '独立性']
  },
  {
    id: 'p2024-02', year: 2024, part: '概率', type: '计算', topic: 'pr07', marks: 20,
    title: '平移指数分布最小值的分布与置信区间',
    prompt: R`设 \(X_1,\ldots,X_n\) 是取自总体 \(X\) 的样本，\(X\) 的密度为 \(f(x)=e^{-(x-\theta)}\ (x\ge\theta)\)，其余为 0。令 \(U=X_{(1)}-\theta\)。（1）求 \(U\) 的分布；（2）求 \(\theta\) 的 \(1-\alpha\) 置信区间。`,
    answer: R`<p><b>（1）最小值：</b>\(X\) 的分布函数 \(F(x)=1-e^{-(x-\theta)}\ (x\ge\theta)\)。最小值 \(X_{(1)}\) 的生存函数：</p>
      \[ P(X_{(1)}>x)=[P(X>x)]^n=e^{-n(x-\theta)},\quad x\ge\theta. \]
      故 \(U=X_{(1)}-\theta\sim Exp(n)\)，密度 \(f_U(u)=n e^{-nu}\ (u>0)\)。
      <p><b>（2）枢轴量：</b>\(2nU\sim\chi^2(2)\)。因此</p>
      \[ P\left(\chi^2_{\alpha/2}(2)\le2n(X_{(1)}-\theta)\le\chi^2_{1-\alpha/2}(2)\right)=1-\alpha. \]
      反解：
      \[ \theta\in\left[X_{(1)}-\frac{\chi^2_{1-\alpha/2}(2)}{2n},\ X_{(1)}-\frac{\chi^2_{\alpha/2}(2)}{2n}\right]. \]
      <p>95% 时，\(\chi^2_{0.975}(2)=7.378,\ \chi^2_{0.025}(2)=0.0506\)，区间为</p>
      \[ \left[X_{(1)}-\frac{3.689}{n},\ X_{(1)}-\frac{0.0253}{n}\right]. \]
      <div class="final">\(U\sim Exp(n)\)；\(\theta\) 的 \(1-\alpha\) 区间为 \([X_{(1)}-\chi^2_{1-\alpha/2}(2)/(2n),\ X_{(1)}-\chi^2_{\alpha/2}(2)/(2n)]\)。</div>`,
    tags: ['次序统计量', '枢轴量', '置信区间']
  },
  {
    id: 'p2024-03', year: 2024, part: '概率', type: '计算', topic: 'pr07', marks: 20,
    title: '双参数分布的充分统计量与极大似然估计',
    prompt: R`设 \(X_1,\ldots,X_n\) 的分布函数为 \(F(x)=(x/\beta)^\alpha\ (0\le x\le\beta)\)，其中 \(\alpha,\beta>0\)。（1）求关于 \((\alpha,\beta)\) 的二维充分统计量；（2）求 \(\alpha,\beta\) 的极大似然估计。`,
    answer: R`<p>密度：</p>
      \[ f(x;\alpha,\beta)=\frac{\alpha x^{\alpha-1}}{\beta^\alpha},\quad 0<x<\beta. \]
      <p><b>（1）似然函数：</b></p>
      \[ L(\alpha,\beta)=\alpha^n\frac{\prod x_i^{\alpha-1}}{\beta^{n\alpha}}\mathbf{1}\{x_{(n)}\le\beta\}. \]
      由因子分解定理，充分统计量为</p>
      \[ \left(\prod_{i=1}^{n}X_i,\ X_{(n)}\right)\quad\text{或}\quad\left(\sum\ln X_i,\ X_{(n)}\right). \]
      <p><b>（2）MLE：</b>固定 \(\alpha\) 时，\(L\) 随 \(\beta\) 增大而减小，且 \(\beta\ge X_{(n)}\)，故</p>
      \[ \hat{\beta}=X_{(n)}. \]
      对数似然：
      \[ \ell=n\ln\alpha+(\alpha-1)\sum\ln x_i-n\alpha\ln\beta. \]
      \[ \frac{\partial\ell}{\partial\alpha}=\frac{n}{\alpha}+\sum\ln x_i-n\ln\beta=0. \]
      \[ \hat{\alpha}=\frac{n}{n\ln X_{(n)}-\sum\ln X_i} =\frac{n}{\sum\ln(X_{(n)}/X_i)}. \]
      <div class="final">充分统计量 \((\prod X_i,X_{(n)})\)；\(\hat{\beta}=X_{(n)}\)，\(\hat{\alpha}=n/\sum\ln(X_{(n)}/X_i)\)。</div>`,
    tags: ['充分统计量', 'MLE', '因子分解']
  },
  {
    id: 'p2024-04', year: 2024, part: '概率', type: '计算', topic: 'pr08', marks: 15,
    title: '正态均值双侧检验的拒绝域常数',
    prompt: R`设 \(X_1,\ldots,X_{25}\) 取自正态总体 \(N(\mu,9)\)，\(\mu\) 未知。检验 \(H_0:\mu=\mu_0\) vs \(H_1:\mu\ne\mu_0\)，拒绝域为 \(\{|\bar{X}-\mu_0|\ge c\}\)。显著性水平 0.05，\(u_{0.975}=1.96\)。求 \(c\)。`,
    answer: R`<p>\(\sigma=3,\ n=25\)，故 \(\bar{X}\sim N(\mu,9/25)\)，标准误 \(3/5=0.6\)。</p>
      <p>在 \(H_0\) 下：</p>
      \[ Z=\frac{\bar{X}-\mu_0}{0.6}\sim N(0,1). \]
      双侧检验：
      \[ P(|Z|\ge1.96)=0.05. \]
      因此
      \[ c=1.96\times0.6=1.176. \]
      <div class="final">\(c=1.176\)。</div>`,
    tags: ['拒绝域', '双侧检验', '临界值']
  },
  {
    id: 'p2025-01', year: 2025, part: '概率', type: '计算', topic: 'pr03', marks: 20,
    title: '二维正态的边缘、条件与线性组合',
    prompt: R`设 \((X,Y)\sim N(\mu_1,\mu_2,\sigma_1^2,\sigma_2^2,\rho)\)。（1）求 \(X\) 的边缘分布；（2）求 \(Y\mid X=x\) 的条件分布；（3）求 \(Z=X^2\) 的分布；（4）求 \(W=3X+4Y+3\) 的分布，并指出分布类型。`,
    answer: R`<p><b>（1）边缘：</b></p>
      \[ X\sim N(\mu_1,\sigma_1^2). \]
      <p><b>（2）条件：</b></p>
      \[ Y\mid X=x\sim N\left(\mu_2+\rho\frac{\sigma_2}{\sigma_1}(x-\mu_1),\ \sigma_2^2(1-\rho^2)\right). \]
      <p><b>（3）\(Z=X^2\)：</b>令 \(U=(X-\mu_1)/\sigma_1\sim N(0,1)\)，则</p>
      \[ Z=\sigma_1^2\left(U+\frac{\mu_1}{\sigma_1}\right)^2. \]
      所以 \(Z/\sigma_1^2\) 服从自由度为 1、非中心参数为 \((\mu_1/\sigma_1)^2\) 的非中心 χ² 分布；当 \(\mu_1=0\) 时，\(Z/\sigma_1^2\sim\chi^2(1)\)。
      <p><b>（4）线性组合：</b>正态变量的线性组合仍正态：</p>
      \[ W\sim N\left(3\mu_1+4\mu_2+3,\ 9\sigma_1^2+16\sigma_2^2+24\rho\sigma_1\sigma_2\right). \]
      <div class="final">\(X\sim N(\mu_1,\sigma_1^2)\)；条件均值 \(\mu_2+\rho\sigma_2(x-\mu_1)/\sigma_1\)，条件方差 \(\sigma_2^2(1-\rho^2)\)；\(Z\) 为非中心 χ²；\(W\) 为正态。</div>`,
    tags: ['二维正态', '条件分布', '非中心卡方']
  },
  {
    id: 'p2025-02', year: 2025, part: '概率', type: '证明', topic: 'pr03', marks: 20,
    title: '联合密度 (1+xy)/4 的依赖性与平方独立性',
    prompt: R`已知 \((X,Y)\) 的联合密度为 \(p(x,y)=\frac{1+xy}{4}\ (|x|<1,|y|<1)\)，其余为 0。证明：\(X\) 与 \(Y\) 不独立，但 \(X^2\) 与 \(Y^2\) 相互独立。（2026 年重复考查）`,
    answer: R`<p><b>边缘密度：</b></p>
      \[ f_X(x)=\int_{-1}^{1}\frac{1+xy}{4}\,\mathrm{d}y=\frac{1}{2},\quad |x|<1; \]
      \[ f_Y(y)=\frac{1}{2},\quad |y|<1. \]
      <p>因为 \(f_X(x)f_Y(y)=\frac14\ne\frac{1+xy}{4}=f(x,y)\)，所以 \(X,Y\) 不独立。</p>
      <p><b>平方独立性：</b>对 \(0\le u,v\le1\)，</p>
      \[ P(X^2\le u,Y^2\le v)=\int_{-\sqrt{u}}^{\sqrt{u}}\int_{-\sqrt{v}}^{\sqrt{v}}\frac{1+xy}{4}\,\mathrm{d}y\,\mathrm{d}x. \]
      <p>对称区间上 \(xy\) 的积分为 0，故</p>
      \[ =\frac{1}{4}(2\sqrt{u})(2\sqrt{v})=\sqrt{uv}. \]
      而
      \[ P(X^2\le u)=P(-\sqrt{u}\le X\le\sqrt{u})=\sqrt{u},\quad P(Y^2\le v)=\sqrt{v}. \]
      因此 \(P(X^2\le u,Y^2\le v)=P(X^2\le u)P(Y^2\le v)\)，即 \(X^2,Y^2\) 独立。</p>
      <div class="final">\(f_X=f_Y=1/2\)，乘积不等于联合密度 ⇒ 不独立；平方的联合分布可分解 ⇒ 平方独立。</div>`,
    tags: ['独立性', '联合密度', '对称性']
  },
  {
    id: 'p2025-03', year: 2025, part: '概率', type: '计算', topic: 'pr07', marks: 20,
    title: '线性回归模型的 MLE 与无偏性',
    prompt: R`设 \(Y_i=\beta X_i+\varepsilon_i\)，\(\varepsilon_i\sim N(0,\sigma^2)\) 独立，\(X_i\) 为非随机常数。求：（1）\(\beta\) 的极大似然估计 \(\hat{\beta}\)，并证明其无偏；（2）\(\hat{\beta}\) 的分布。`,
    answer: R`<p><b>（1）似然：</b></p>
      \[ L(\beta,\sigma^2)=\prod_{i=1}^{n}\frac{1}{\sqrt{2\pi}\sigma}\exp\left[-\frac{(Y_i-\beta X_i)^2}{2\sigma^2}\right]. \]
      对数似然对 \(\beta\) 求导：
      \[ \frac{\partial\ell}{\partial\beta}=\frac{1}{\sigma^2}\sum X_i(Y_i-\beta X_i)=0, \]
      \[ \hat{\beta}=\frac{\sum X_iY_i}{\sum X_i^2}. \]
      <p><b>无偏性：</b></p>
      \[ E(\hat{\beta})=\frac{\sum X_iE(Y_i)}{\sum X_i^2} =\frac{\sum X_i\cdot\beta X_i}{\sum X_i^2}=\beta. \]
      <p><b>（2）分布：</b>\(Y_i\) 独立正态，故 \(\hat{\beta}\) 是正态的线性组合：</p>
      \[ \hat{\beta}\sim N\left(\beta,\ \frac{\sigma^2}{\sum X_i^2}\right). \]
      <div class="final">\(\hat{\beta}=\sum X_iY_i/\sum X_i^2\)，无偏；\(\hat{\beta}\sim N(\beta,\sigma^2/\sum X_i^2)\)。</div>`,
    tags: ['MLE', '无偏性', '线性回归']
  },
  {
    id: 'p2025-04', year: 2025, part: '概率', type: '证明', topic: 'pr08', marks: 20,
    title: '未知方差下正态均值 t 检验的 size',
    prompt: R`设 \(X_1,\ldots,X_n\sim N(\mu,\sigma^2)\)，\(\mu,\sigma^2\) 均未知。证明：检验 \(H_0:\mu\le\mu_0\) vs \(H_1:\mu>\mu_0\) 的 t 检验，其显著性水平为 \(\alpha\)。`,
    answer: R`<p>检验统计量：</p>
      \[ T=\frac{\bar{X}-\mu_0}{S/\sqrt{n}}. \]
      <p>在 \(H_0\) 的边界 \(\mu=\mu_0\) 上：</p>
      \[ \frac{\bar{X}-\mu_0}{\sigma/\sqrt{n}}\sim N(0,1),\qquad \frac{(n-1)S^2}{\sigma^2}\sim\chi^2(n-1), \]
      且二者独立。因此
      \[ T=\frac{\frac{\bar{X}-\mu_0}{\sigma/\sqrt{n}}}{\sqrt{\frac{(n-1)S^2/\sigma^2}{n-1}}}\sim t(n-1). \]
      <p>取拒绝域 \(T>t_{1-\alpha}(n-1)\)，则</p>
      \[ P_{\mu=\mu_0}(T>t_{1-\alpha}(n-1))=\alpha. \]
      当 \(\mu<\mu_0\) 时，\(T\) 的分布向左平移，拒绝概率更小；故该检验的 size 为 \(\alpha\)。</p>
      <div class="final">在边界上 \(T\sim t(n-1)\)，由分位数定义得 \(P(T>t_{1-\alpha})=\alpha\)，故 size=α。</div>`,
    tags: ['t检验', 'size', '拒绝域']
  },
  {
    id: 'p2026-01', year: 2026, part: '概率', type: '证明', topic: 'pr03', marks: 20,
    title: '联合密度的依赖性与平方独立性（2026）',
    prompt: R`已知 \((X,Y)\) 的联合密度为 \(p(x,y)=\frac{1+xy}{4}\ (|x|<1,|y|<1)\)。证明：\(X\) 与 \(Y\) 不独立，\(X^2\) 与 \(Y^2\) 相互独立。`,
    answer: R`<p>与 2025 年题同源，标准解法是“先求边缘，再看乘积；平方用对称区间积分”。</p>
      <p>边缘：\(f_X(x)=1/2,\ f_Y(y)=1/2\)，但 \(f(x,y)=(1+xy)/4\ne1/4\)，故不独立。</p>
      <p>平方：</p>
      \[ P(X^2\le u,Y^2\le v)=\int_{-\sqrt{u}}^{\sqrt{u}}\int_{-\sqrt{v}}^{\sqrt{v}}\frac{1+xy}{4}\,\mathrm{d}y\,\mathrm{d}x =\sqrt{uv}, \]
      而 \(P(X^2\le u)=\sqrt{u},\ P(Y^2\le v)=\sqrt{v}\)，故独立。</p>
      <div class="final">同 2025 年：不独立；平方独立。</div>`,
    tags: ['独立性', '平方变换', '重复考点']
  },
  {
    id: 'p2014-01', year: 2014, part: '概率', type: '计算', topic: 'pr02', marks: 15,
    title: '密度函数求常数、分布函数与区间概率（改编）',
    prompt: R`设随机变量 \(X\) 的密度函数为 \(f(x)=Kx\ (0<x<2)\)，其余为 0。求：（1）常数 \(K\)；（2）分布函数 \(F(x)\)；（3）\(P(0.5<X<1.5)\)。`,
    answer: R`<p><b>（1）归一化：</b></p>
      \[ \int_0^2Kx\,\mathrm{d}x=K\cdot\frac{2^2}{2}=2K=1\Rightarrow K=\frac12. \]
      <p><b>（2）分布函数：</b>当 \(0\le x<2\) 时，</p>
      \[ F(x)=\int_0^x\frac{t}{2}\,\mathrm{d}t=\frac{x^2}{4}. \]
      因此
      \[ F(x)=\begin{cases}0,&x<0,\\ \frac{x^2}{4},&0\le x<2,\\ 1,&x\ge2.\end{cases} \]
      <p><b>（3）区间概率：</b></p>
      \[ P(0.5<X<1.5)=F(1.5)-F(0.5)=\frac{1.5^2}{4}-\frac{0.5^2}{4}=0.5. \]
      <div class="final">\(K=1/2\)；\(F(x)=x^2/4\ (0\le x<2)\)；概率 0.5。</div>`,
    tags: ['密度函数', '分布函数', '改编']
  },
  {
    id: 'p2016-02', year: 2016, part: '概率', type: '简答', topic: 'pr05', marks: 25,
    title: '概率三大公理与中心极限定理',
    prompt: R`（1）简述概率的三大公理。（2）请列举出你所知道的中心极限定理，并谈谈对其的认识。`,
    answer: R`<p><b>（1）概率三大公理：</b></p>
      <ol>
        <li><b>非负性：</b>对任意事件 \(A\)，\(P(A)\ge0\)。</li>
        <li><b>规范性：</b>样本空间 \(\Omega\) 的概率 \(P(\Omega)=1\)。</li>
        <li><b>可列可加性：</b>若 \(A_1,A_2,\ldots\) 两两互斥，则 \(P(\bigcup_{i=1}^{\infty}A_i)=\sum_{i=1}^{\infty}P(A_i)\)。</li>
      </ol>
      <p><b>（2）中心极限定理：</b></p>
      <p><b>独立同分布 CLT：</b>设 \(X_1,X_2,\ldots\) 独立同分布，\(E(X_i)=\mu,\ Var(X_i)=\sigma^2<\infty\)，则</p>
      \[ \frac{\sum_{i=1}^{n}X_i-n\mu}{\sqrt{n}\sigma}\xrightarrow{d}N(0,1). \]
      <p><b>棣莫弗—拉普拉斯 CLT：</b>若 \(X\sim B(n,p)\)，则</p>
      \[ \frac{X-np}{\sqrt{np(1-p)}}\xrightarrow{d}N(0,1). \]
      <p><b>认识：</b>CLT 说明大量独立随机因素叠加后近似正态，是抽样推断中大样本近似的基础；它不要求总体正态，只要求方差有限；样本均值的标准差是 \(\sigma/\sqrt{n}\)。大数定律说“平均结果稳定”，CLT 说“分布趋近正态”，二者不同但相互补充。</p>
      <div class="final">三条公理：非负、规范、可列可加；CLT：独立同分布/二项分布的正态近似。</div>`,
    tags: ['概率公理', '中心极限定理', '大数定律']
  }

];

})();

