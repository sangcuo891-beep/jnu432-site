#!/usr/bin/env python3
"""
暨南大学 432 统计学复习网站 · 服务器
- 静态站点
- /api/auth/*：注册、登录、当前用户、退出
- /api/progress：账号进度云同步
- /api/chat：DeepSeek API 代理

运行：
    $env:DEEPSEEK_API_KEY="sk-..."   # 可选，也可在网页里填
    python server.py

外网访问：
    cloudflared tunnel --url http://127.0.0.1:8123
"""
import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import sys
import time
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
DATA_DIR.mkdir(exist_ok=True)
DB_PATH = DATA_DIR / "app.db"
API_URL = os.environ.get("DEEPSEEK_API_URL", "https://api.deepseek.com/chat/completions")
API_KEY = os.environ.get("DEEPSEEK_API_KEY", "").strip()
SESSION_DAYS = 30


def db():
    conn = sqlite3.connect(str(DB_PATH), timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with db() as conn:
        conn.executescript(
            """
            create table if not exists users(
              id integer primary key autoincrement,
              email text unique not null,
              salt text not null,
              pw_hash text not null,
              created_at integer not null
            );
            create table if not exists sessions(
              token text primary key,
              user_id integer not null,
              expires_at integer not null
            );
            create table if not exists progress(
              user_id integer primary key,
              state text not null,
              updated_at integer not null
            );
            """
        )


def hash_password(password, salt):
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), 200_000).hex()


def make_token():
    return secrets.token_urlsafe(32)


def public_user(row):
    return {"id": row["id"], "email": row["email"]}


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-API-Key")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS, GET")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    # -------- static guard --------
    def do_GET(self):
        path = urlparse(self.path).path
        if path.startswith("/data/") or path in ("/server.py", "/data"):
            self.send_error(404)
            return
        if path == "/api/me":
            self.api_me()
            return
        if path == "/api/progress":
            self.api_get_progress()
            return
        super().do_GET()

    def do_POST(self):
        path = urlparse(self.path).path
        if path == "/api/register":
            self.api_register()
        elif path == "/api/login":
            self.api_login()
        elif path == "/api/logout":
            self.api_logout()
        elif path == "/api/chat":
            self.api_chat()
        else:
            self.send_error(404, "Not Found")

    def do_PUT(self):
        if urlparse(self.path).path == "/api/progress":
            self.api_put_progress()
        else:
            self.send_error(404, "Not Found")

    # -------- helpers --------
    def read_json(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
            return json.loads(self.rfile.read(length).decode("utf-8"))
        except Exception as exc:
            self.json(400, {"error": {"message": f"无效请求：{exc}"}})
            return None

    def json(self, status, obj):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def auth_user(self):
        header = self.headers.get("Authorization", "")
        if not header.startswith("Bearer "):
            return None
        token = header[7:].strip()
        with db() as conn:
            row = conn.execute(
                "select u.id,u.email,s.expires_at from sessions s join users u on u.id=s.user_id where s.token=?",
                (token,),
            ).fetchone()
            if not row:
                return None
            if row["expires_at"] < int(time.time()):
                conn.execute("delete from sessions where token=?", (token,))
                return None
            return row

    def require_user(self):
        user = self.auth_user()
        if not user:
            self.json(401, {"error": {"message": "请先登录"}})
            return None
        return user

    # -------- auth --------
    def api_register(self):
        payload = self.read_json()
        if payload is None:
            return
        email = (payload.get("email") or "").strip().lower()
        password = payload.get("password") or ""
        if "@" not in email or len(password) < 6:
            self.json(400, {"error": {"message": "请输入有效邮箱，密码至少 6 位"}})
            return
        salt = secrets.token_hex(16)
        pw = hash_password(password, salt)
        try:
            with db() as conn:
                cur = conn.execute(
                    "insert into users(email,salt,pw_hash,created_at) values(?,?,?,?)",
                    (email, salt, pw, int(time.time())),
                )
                uid = cur.lastrowid
                token = make_token()
                conn.execute(
                    "insert into sessions(token,user_id,expires_at) values(?,?,?)",
                    (token, uid, int(time.time()) + SESSION_DAYS * 86400),
                )
            self.json(200, {"token": token, "user": {"id": uid, "email": email}})
        except sqlite3.IntegrityError:
            self.json(409, {"error": {"message": "该邮箱已注册，请直接登录"}})

    def api_login(self):
        payload = self.read_json()
        if payload is None:
            return
        email = (payload.get("email") or "").strip().lower()
        password = payload.get("password") or ""
        with db() as conn:
            row = conn.execute("select * from users where email=?", (email,)).fetchone()
            if not row or not hmac.compare_digest(row["pw_hash"], hash_password(password, row["salt"])):
                self.json(401, {"error": {"message": "邮箱或密码错误"}})
                return
            token = make_token()
            conn.execute(
                "insert into sessions(token,user_id,expires_at) values(?,?,?)",
                (token, row["id"], int(time.time()) + SESSION_DAYS * 86400),
            )
        self.json(200, {"token": token, "user": public_user(row)})

    def api_me(self):
        user = self.require_user()
        if user:
            self.json(200, {"user": public_user(user)})

    def api_logout(self):
        header = self.headers.get("Authorization", "")
        if header.startswith("Bearer "):
            with db() as conn:
                conn.execute("delete from sessions where token=?", (header[7:].strip(),))
        self.json(200, {"ok": True})

    # -------- progress --------
    def api_get_progress(self):
        user = self.require_user()
        if not user:
            return
        with db() as conn:
            row = conn.execute("select state,updated_at from progress where user_id=?", (user["id"],)).fetchone()
        self.json(200, {"state": json.loads(row["state"]) if row else None, "updated_at": row["updated_at"] if row else 0})

    def api_put_progress(self):
        user = self.require_user()
        if not user:
            return
        payload = self.read_json()
        if payload is None:
            return
        state = payload.get("state")
        if not isinstance(state, dict):
            self.json(400, {"error": {"message": "state 必须是对象"}})
            return
        now = int(time.time())
        with db() as conn:
            conn.execute(
                "insert into progress(user_id,state,updated_at) values(?,?,?) "
                "on conflict(user_id) do update set state=excluded.state,updated_at=excluded.updated_at",
                (user["id"], json.dumps(state, ensure_ascii=False), now),
            )
        self.json(200, {"ok": True, "updated_at": now})

    # -------- AI proxy --------
    def api_chat(self):
        payload = self.read_json()
        if payload is None:
            return
        key = (self.headers.get("X-API-Key") or API_KEY).strip()
        if not key:
            self.json(401, {"error": {"message": "未配置 DeepSeek API Key。请登录后在「AI 助教」填写，或设置环境变量 DEEPSEEK_API_KEY。"}})
            return
        body = {
            "model": payload.get("model") or "deepseek-chat",
            "messages": payload.get("messages") or [],
            "temperature": payload.get("temperature", 0.3),
            "stream": False,
        }
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(
            API_URL,
            data=data,
            headers={"Content-Type": "application/json", "Authorization": f"Bearer {key}"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                result = resp.read()
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(result)))
            self.end_headers()
            self.wfile.write(result)
        except urllib.error.HTTPError as exc:
            result = exc.read()
            self.send_response(exc.code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(result)))
            self.end_headers()
            self.wfile.write(result)
        except Exception as exc:
            self.json(502, {"error": {"message": f"代理请求失败：{exc}"}})

    def log_message(self, fmt, *args):
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))


if __name__ == "__main__":
    init_db()
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "8123"))
    print(f"Serving {ROOT} at http://{host}:{port}/")
    print("Auth: /api/register /api/login /api/me /api/progress /api/logout")
    print("DeepSeek proxy: POST /api/chat")
    ThreadingHTTPServer((host, port), Handler).serve_forever()
