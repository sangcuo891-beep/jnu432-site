﻿/* 合并题库：统计学原理 + 概率论与数理统计
   注：s2017-02、p2014-01 为补充练习，不属于原卷真题，故不进入真题库。 */
window.BANK = [
  ...(window.BANK_STATS || []),
  ...(window.BANK_PROB || []),
  ...(window.BANK_EXTRA || []),
  ...(window.BANK_RECENT || [])
].filter(q => q.id !== 's2017-02' && q.id !== 'p2014-01');



