﻿/* ============================================================
   暨南大学 432 统计学 · 前端应用
   Vanilla JS, hash router, localStorage, KaTeX auto-render
   ============================================================ */
(function () {
  'use strict';

  const TOPICS = window.TOPICS || [];
  const BANK = window.BANK || [];
  const MOCKS = window.MOCKS || [];
  const CARDS = window.CARDS || [];
  const SOURCES = window.SOURCES || [];
  const NOTES = window.NOTES || [];
  const TOPIC_MAP = Object.fromEntries(TOPICS.map(t => [t.id, t]));
  const CARD_MAP = Object.fromEntries(CARDS.map(c => [c.id, c]));
  const BANK_MAP = Object.fromEntries(BANK.map(q => [q.id, q]));

  /* 题目/解析里混有 HTML 标签与数学不等式（如 0<x<2）。
     先把合法 HTML 标签占位，再把裸 < > 转义，避免浏览器把不等式当成标签。 */
  const HTML_TAG_RE = /<\/?(?:p|ul|ol|li|div|span|b|strong|em|i|br|h[1-6]|table|thead|tbody|tr|td|th|sub|sup|code|pre|hr|blockquote|a)\b[^>]*>/gi;
  function safeMathHtml(html) {
    if (typeof html !== 'string') return html;
    const tags = [];
    let s = html.replace(HTML_TAG_RE, (m) => { tags.push(m); return `\u0000${tags.length - 1}\u0000`; });
    s = s.replace(/</g, '&lt;').replace(/>/g, '&gt;');
    s = s.replace(/\u0000(\d+)\u0000/g, (_, i) => tags[Number(i)]);
    return s;
  }
  function sanitizeRecord(obj, keys) {
    if (!obj || typeof obj !== 'object') return;
    for (const k of Object.keys(obj)) {
      const v = obj[k];
      if (typeof v === 'string' && keys.includes(k)) obj[k] = safeMathHtml(v);
      else if (Array.isArray(v)) v.forEach((x, i) => {
        if (typeof x === 'string' && keys.includes(k)) v[i] = safeMathHtml(x);
        else sanitizeRecord(x, keys);
      });
      else if (v && typeof v === 'object') sanitizeRecord(v, keys);
    }
  }
  const SAFE_KEYS = ['title', 'subtitle', 'prompt', 'answer', 'overview', 'tex', 'note', 'q', 'a', 'mnemonic', 'strategy', 'pitfalls'];
  [...TOPICS, ...BANK, ...MOCKS, ...CARDS].forEach(x => sanitizeRecord(x, SAFE_KEYS));

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const esc = (s) => String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  const pct = (a, b) => b ? Math.round(a / b * 100) : 0;
  const today = () => new Date().toISOString().slice(0, 10);
  const addDays = (n) => { const d = new Date(); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };
  const uid = () => Math.random().toString(36).slice(2, 9);

  /* ---------------- state ---------------- */
  const KEY = 'jnu432_state_v1';
  const DEFAULT_STATE = {
    answers: {}, cards: {}, mocks: {}, plan: {},
    history: [], examDate: '2026-12-19', theme: 'light', createdAt: Date.now()
  };
  function loadState() {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return { ...DEFAULT_STATE };
      const s = JSON.parse(raw);
      return {
        ...DEFAULT_STATE, ...s,
        answers: s.answers || {}, cards: s.cards || {}, mocks: s.mocks || {},
        plan: s.plan || {}, history: Array.isArray(s.history) ? s.history : []
      };
    } catch (e) { return { ...DEFAULT_STATE }; }
  }
  let state = loadState();
  const TOKEN_KEY = 'jnu432_token';
  let currentUser = null;
  let cloudTimer = null;
  let cloudBusy = false;
  let applyingCloud = false;
  let cloudStatus = 'local';

  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) { toast('本地存储不可用，进度可能无法保存'); }
    updateSideProgress();
    if (!applyingCloud) queueCloudPush();
  }
  function getToken() { try { return localStorage.getItem(TOKEN_KEY) || ''; } catch (e) { return ''; } }
  function setToken(t) { try { t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY); } catch (e) {} }
  function updateAccountChip() {
    const el = $('#account-chip'); if (!el) return;
    el.textContent = currentUser ? (currentUser.email.split('@')[0].slice(0, 12)) : '登录';
    el.title = currentUser ? currentUser.email : '登录 / 注册';
  }
  async function api(path, opts = {}) {
    const headers = { ...(opts.headers || {}) };
    const token = getToken();
    if (token) headers.Authorization = 'Bearer ' + token;
    const res = await fetch(path, { ...opts, headers });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data?.error?.message || ('HTTP ' + res.status));
    return data;
  }
  function mergeCloud(cloud) {
    if (!cloud || typeof cloud !== 'object') return;
    applyingCloud = true;
    const ans = { ...(cloud.answers || {}) };
    Object.entries(state.answers || {}).forEach(([id, v]) => {
      const old = ans[id];
      if (!old || (v.updated || 0) >= (old.updated || 0)) ans[id] = v;
    });
    state.answers = ans;
    const cards = { ...(cloud.cards || {}) };
    Object.entries(state.cards || {}).forEach(([id, v]) => {
      const old = cards[id];
      if (!old || (v.last || 0) >= (old.last || 0)) cards[id] = v;
    });
    state.cards = cards;
    const mocks = { ...(cloud.mocks || {}) };
    Object.entries(state.mocks || {}).forEach(([id, v]) => {
      const old = mocks[id];
      if (!old || (v.submittedAt || 0) >= (old.submittedAt || 0) || (!old.submitted && v.submitted)) mocks[id] = v;
    });
    state.mocks = mocks;
    state.plan = { ...(cloud.plan || {}), ...(state.plan || {}) };
    state.history = [...new Set([...(cloud.history || []), ...(state.history || [])])].slice(-400);
    applyingCloud = false;
  }
  function queueCloudPush() {
    if (!getToken()) return;
    clearTimeout(cloudTimer);
    cloudTimer = setTimeout(pushCloud, 900);
  }
  async function pushCloud() {
    if (!getToken() || cloudBusy) return;
    cloudBusy = true; cloudStatus = 'syncing';
    try {
      await api('/api/progress', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ state }) });
      cloudStatus = 'synced';
    } catch (e) {
      cloudStatus = 'error';
      if (String(e.message).includes('先登录')) { setToken(''); currentUser = null; updateAccountChip(); }
    } finally { cloudBusy = false; }
  }
  async function pullCloud() {
    if (!getToken()) return;
    const data = await api('/api/progress');
    if (data.state) { mergeCloud(data.state); save(); }
    cloudStatus = 'synced';
  }
  async function initCloud() {
    if (!getToken()) { updateAccountChip(); return; }
    try {
      const me = await api('/api/me');
      currentUser = me.user; updateAccountChip();
      await pullCloud();
    } catch (e) {
      setToken(''); currentUser = null; cloudStatus = 'local'; updateAccountChip();
    }
  }
  function touchHistory() {
    const d = today();
    if (!state.history.includes(d)) { state.history.push(d); if (state.history.length > 400) state.history = state.history.slice(-400); }
  }
  function toast(msg) {
    const t = $('#toast'); if (!t) return;
    t.textContent = msg; t.classList.add('show');
    clearTimeout(t._timer); t._timer = setTimeout(() => t.classList.remove('show'), 2100);
  }

  /* ---------------- math ---------------- */
  let mathTimer = null;
  function typeset(root = document) {
    if (!window.renderMathInElement) return;
    try {
      window.renderMathInElement(root, {
        delimiters: [
          { left: '\\[', right: '\\]', display: true },
          { left: '$$', right: '$$', display: true },
          { left: '\\(', right: '\\)', display: false },
          { left: '$', right: '$', display: false }
        ],
        throwOnError: false,
        strict: false,
        trust: true,
        macros: {
          '\\E': '\\operatorname{E}',
          '\\Var': '\\operatorname{Var}',
          '\\Cov': '\\operatorname{Cov}',
          '\\MSE': '\\operatorname{MSE}',
          '\\R': '\\mathbb{R}'
        }
      });
    } catch (e) { /* keep raw text */ }
  }
  function scheduleTypeset(root) {
    clearTimeout(mathTimer);
    mathTimer = setTimeout(() => typeset(root), 30);
  }
  window.addEventListener('load', () => setTimeout(() => typeset(document), 80));

  /* ---------------- small components ---------------- */
  function chip(text, cls = '') { return `<span class="pill ${cls}">${esc(text)}</span>`; }
  function dots(n, max = 5) {
    return `<span class="freq-dots">${Array.from({ length: max }, (_, i) => `<i class="${i < n ? 'on' : ''}"></i>`).join('')}</span>`;
  }
  function bar(percent, cls = '') {
    return `<div class="bar ${cls}"><i style="width:${Math.max(0, Math.min(100, percent))}%"></i></div>`;
  }
  function pageHead(eyebrow, title, sub, actions = '') {
    return `<div class="page-head"><div><div class="eyebrow">${esc(eyebrow)}</div><h1 class="page-title">${title}</h1>${sub ? `<p class="page-sub">${sub}</p>` : ''}</div><div class="head-actions">${actions}</div></div>`;
  }
  function emptyBox(title, text) {
    return `<div class="empty"><b>${esc(title)}</b>${esc(text)}</div>`;
  }

  /* ---------------- progress ---------------- */
  function answerStats(list = BANK) {
    let seen = 0, ok = 0, bad = 0;
    list.forEach(q => {
      const a = state.answers[q.id];
      if (a) { seen++; if (a.status === 'ok') ok++; if (a.status === 'bad') bad++; }
    });
    return { seen, ok, bad, total: list.length };
  }
  function cardStats() {
    let mastered = 0, learning = 0, due = 0;
    CARDS.forEach(c => {
      const s = state.cards[c.id];
      if (s && s.level >= 4) mastered++;
      else if (s) learning++;
      if (!s || (s.due || '') <= today()) due++;
    });
    return { mastered, learning, due, total: CARDS.length };
  }
  function mockStats() {
    const done = MOCKS.filter(m => state.mocks[m.id] && state.mocks[m.id].submitted).length;
    return { done, total: MOCKS.length };
  }
  function overallProgress() {
    const a = answerStats(), c = cardStats(), m = mockStats();
    const p = (a.seen / Math.max(1, a.total)) * 40 + (c.mastered / Math.max(1, c.total)) * 35 + (m.done / Math.max(1, m.total)) * 25;
    return Math.round(p);
  }
  function updateSideProgress() {
    const p = overallProgress();
    const el = $('#side-progress'), barEl = $('#side-progress-bar');
    if (el) el.textContent = p + '%';
    if (barEl) barEl.style.width = p + '%';
  }
  function topicStats(id) {
    const qs = BANK.filter(q => q.topic === id);
    const a = answerStats(qs);
    return { ...a, pct: pct(a.seen, a.total) };
  }

  /* ---------------- router ---------------- */
  const routes = [
    { re: /^\/$/, title: '学习总览', nav: 'dashboard', fn: renderDashboard },
    { re: /^\/topics$/, title: '题型与策略', nav: 'topics', fn: renderTopics },
    { re: /^\/topic\/([^/]+)$/, title: '题型详解', nav: 'topics', fn: renderTopic },
    { re: /^\/bank$/, title: '历年真题库', nav: 'bank', fn: renderBank },
    { re: /^\/drill$/, title: '逐题刷', nav: 'drill', fn: renderDrill },
    { re: /^\/sources$/, title: '真题原卷', nav: 'sources', fn: renderSources },
    { re: /^\/source\/([^/]+)$/, title: '真题原卷', nav: 'sources', fn: renderSource },
    { re: /^\/mocks$/, title: '三套模拟卷', nav: 'mocks', fn: renderMocks },
    { re: /^\/mock\/([^/]+)$/, title: '模拟卷', nav: 'mocks', fn: renderMock },
    { re: /^\/recite$/, title: '原理背诵', nav: 'recite', fn: renderRecite },
    { re: /^\/notes$/, title: '背诵原文', nav: 'notes', fn: renderNotes },
    { re: /^\/note\/(\d+)$/, title: '背诵原文', nav: 'notes', fn: renderNotePage },
    { re: /^\/ai$/, title: 'AI 助教', nav: 'ai', fn: renderAI },
    { re: /^\/review$/, title: '多轮复习', nav: 'review', fn: renderReview },
    { re: /^\/plan$/, title: '复习路线', nav: 'plan', fn: renderPlan },
    { re: /^\/account$/, title: '账号与同步', nav: 'account', fn: renderAccount },
    { re: /^\/search$/, title: '搜索', nav: '', fn: renderSearch }
  ];
  function parseHash() {
    let h = location.hash.replace(/^#/, '') || '/';
    const qi = h.indexOf('?');
    const path = qi >= 0 ? h.slice(0, qi) : h;
    const query = Object.fromEntries(new URLSearchParams(qi >= 0 ? h.slice(qi + 1) : ''));
    return { path, query };
  }
  function route() {
    const { path, query } = parseHash();
    let match = null, r = null;
    for (const item of routes) {
      const m = path.match(item.re);
      if (m) { match = m; r = item; break; }
    }
    if (!r) { location.hash = '#/'; return; }
    $$('.nav a, .mobile-nav a').forEach(a => a.classList.toggle('active', a.dataset.nav === r.nav));
    const titleEl = $('#topbar-title'); if (titleEl) titleEl.textContent = r.title;
    $('#sidebar')?.classList.remove('open');
    window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' });
    r.fn(match && match.slice(1), query);
    updateSideProgress();
  }
  window.addEventListener('hashchange', route);

  /* ---------------- dashboard ---------------- */
  function renderDashboard() {
    const a = answerStats(), c = cardStats(), m = mockStats();
    const overall = overallProgress();
    const days = Math.max(0, Math.ceil((new Date(state.examDate + 'T00:00:00') - new Date()) / 86400000));
    const dueCards = CARDS.filter(cd => { const s = state.cards[cd.id]; return !s || (s.due || '') <= today(); });
    const wrong = BANK.filter(q => state.answers[q.id]?.status === 'bad');
    const nextQ = BANK.filter(q => !state.answers[q.id]).slice(0, 4);
    const todayDone = state.history.includes(today());
    const topicsSorted = [...TOPICS].sort((x, y) => y.freq - x.freq).slice(0, 6);

    $('#app').innerHTML = `
      <section class="hero">
        <div class="hero-grid">
          <div>
            <div class="eyebrow" style="color:#e5b46a">JINAN UNIVERSITY · 432 STATISTICS</div>
            <h1>把真题拆成题型，<br/>把背诵练成<em>条件反射</em>。</h1>
            <p>2011—2026 历年真题归类 · 三套趋势模拟卷 · 统计学原理背诵卡 · 多轮复习节奏。所有公式、解析与易错点都在一个工作台里。</p>
            <div class="hero-actions">
              <a class="btn accent" href="#/bank">开始刷真题</a>
              <a class="btn" href="#/recite">今日背诵</a>
              <a class="btn" href="#/mocks">进入模拟卷</a>
            </div>
            <div class="hero-meta">
              <div><b>${BANK.length}</b><span>道精编真题</span></div>
              <div><b>${CARDS.length}</b><span>张背诵卡</span></div>
              <div><b>${MOCKS.length}</b><span>套模拟卷</span></div>
              <div><b>${days}</b><span>天后的初试</span></div>
            </div>
          </div>
          <div class="ring-wrap">
            <div class="ring" style="--v:${overall}">
              <div class="ring-in"><b>${overall}%</b><span>总进度</span></div>
            </div>
          </div>
        </div>
      </section>

      <div class="dash-stats">
        <div class="stat-card accent"><span class="stat-ico">▤</span><b>${a.seen}<small style="font-size:12px;color:var(--muted)">/${a.total}</small></b><span>真题已做 · 正确 ${a.ok}</span></div>
        <div class="stat-card teal"><span class="stat-ico">✦</span><b>${c.mastered}<small style="font-size:12px;color:var(--muted)">/${c.total}</small></b><span>背诵已掌握 · 待复习 ${c.due}</span></div>
        <div class="stat-card gold"><span class="stat-ico">◫</span><b>${m.done}<small style="font-size:12px;color:var(--muted)">/${m.total}</small></b><span>模拟卷已完成</span></div>
        <div class="stat-card ok"><span class="stat-ico">↻</span><b>${wrong.length}</b><span>错题待回炉</span></div>
      </div>

      <div class="dash-cols">
        <div class="card">
          <div class="section-head"><h2 class="section-title">今天先做这三件事</h2><span class="small muted">${todayDone ? '今日已打卡' : '完成后自动记录'}</span></div>
          <div class="today-list">
            <a class="today-item" href="#/recite"><span class="ti-ico">✦</span><div><b>背 ${Math.min(20, Math.max(1, dueCards.length))} 张原理卡</b><span>优先到期卡 · 先回忆再看答案</span></div></a>
            <a class="today-item" href="#/bank?status=new"><span class="ti-ico">▤</span><div><b>做 ${Math.min(5, Math.max(1, nextQ.length))} 道真题</b><span>按题型刷 · 先写步骤再对解析</span></div></a>
            <a class="today-item" href="#/review"><span class="ti-ico">↻</span><div><b>回炉 ${Math.min(3, wrong.length || 3)} 道错题</b><span>错题本按遗忘曲线重新排队</span></div></a>
          </div>
          <div class="divider"></div>
          <div class="row"><span class="small muted">复习节奏</span><span class="spacer"></span><a class="btn small ghost" href="#/plan">查看三轮路线 →</a></div>
        </div>

        <div class="card">
          <div class="section-head"><h2 class="section-title">分模块进度</h2><span class="small muted">按真题覆盖</span></div>
          <div class="progress-list">
            ${['统计', '概率'].map(part => {
              const qs = BANK.filter(q => q.part === part), s = answerStats(qs);
              return `<div class="pl-row"><span>${part}·真题</span>${bar(pct(s.seen, s.total))}<b>${pct(s.seen, s.total)}%</b></div>`;
            }).join('')}
            <div class="pl-row"><span>背诵卡</span>${bar(pct(c.mastered, c.total))}<b>${pct(c.mastered, c.total)}%</b></div>
            <div class="pl-row"><span>模拟卷</span>${bar(pct(m.done, m.total))}<b>${pct(m.done, m.total)}%</b></div>
          </div>
          <div class="divider"></div>
          <div class="small muted" style="margin-bottom:6px">最近 28 天学习记录</div>
          <div class="heatmap">
            ${Array.from({ length: 28 }, (_, i) => {
              const d = new Date(); d.setDate(d.getDate() - (27 - i));
              const ds = d.toISOString().slice(0, 10);
              const has = state.history.includes(ds);
              return `<i class="${has ? 'l' + (1 + (i % 4)) : ''}" title="${ds}${has ? ' 已学习' : ''}"></i>`;
            }).join('')}
          </div>
          <div class="legend"><span class="dot" style="background:var(--paper-3)"></span>未学习 <span class="dot" style="background:#4f8a63"></span>已学习</div>
        </div>
      </div>

      <section class="section">
        <div class="section-head"><h2 class="section-title">高频题型 · 先攻主干</h2><a class="btn small ghost" href="#/topics">全部 20 个题型 →</a></div>
        <div class="topic-grid">
          ${topicsSorted.map(t => topicCard(t)).join('')}
        </div>
      </section>

      <section class="section">
        <div class="section-head"><h2 class="section-title">三轮复习路线</h2><a class="btn small ghost" href="#/plan">展开计划 →</a></div>
        <div class="grid grid-3">
          ${[
            { n: '01', t: '基础建网', d: '题型页 + 背诵卡，先建立「看到题知道考什么」的条件反射。', p: Math.round((c.mastered / Math.max(1, c.total)) * 100) },
            { n: '02', t: '真题归类', d: '按题型刷 2011—2026 真题，错题进入回炉队列。', p: pct(a.seen, a.total) },
            { n: '03', t: '整卷模拟', d: '三套 150 分模拟卷，180 分钟限时，训练时间分配。', p: pct(m.done, m.total) }
          ].map(x => `<div class="card"><div class="eyebrow">ROUND ${x.n}</div><h3 style="font-size:18px">${x.t}</h3><p class="small muted">${x.d}</p>${bar(x.p)}<div class="small muted" style="margin-top:5px">${x.p}%</div></div>`).join('')}
        </div>
      </section>
    `;
    scheduleTypeset($('#app'));
  }

  function topicCard(t) {
    const s = topicStats(t.id);
    return `<a class="topic-card" href="#/topic/${t.id}" style="--tc:${t.color || 'var(--accent)'}">
      <div class="tc-top"><div><div class="tc-id">${t.id.toUpperCase()} · ${esc(t.part)}</div><h3>${esc(t.title)}</h3></div>${dots(t.freq)}</div>
      <p>${esc(t.subtitle)}</p>
      <div class="tc-foot"><span class="small muted">真题 ${s.seen}/${s.total} 已做</span>${chip(t.stars + ' 星重点', t.part === '统计' ? 'accent' : 'teal')}</div>
    </a>`;
  }

  /* ---------------- topics ---------------- */
  function renderTopics() {
    const stat = TOPICS.filter(t => t.part === '统计');
    const prob = TOPICS.filter(t => t.part === '概率');
    $('#app').innerHTML = `
      ${pageHead('QUESTION TYPES · 题型地图', '题型 + 真题 + 策略 + 易错点', '先把「考什么」看清楚：每个题型都给出考频、核心公式、解题步骤、易错点与代表真题。', `<a class="btn" href="#/bank">直接刷题</a>`)}
      <div class="note" style="margin-bottom:18px"><b>使用顺序：</b>一轮先读题型页的「策略 + 公式」，二轮用真题库按题型刷，三轮用模拟卷整卷训练。星号越多，近三年重复出现概率越高。</div>
      <section class="section" style="margin-top:0">
        <div class="section-head"><h2 class="section-title">一、统计学原理 · 75 分</h2><span class="small muted">简答 3×10 + 计算 3×15</span></div>
        <div class="topic-grid">${stat.map(topicCard).join('')}</div>
      </section>
      <section class="section">
        <div class="section-head"><h2 class="section-title">二、概率论与数理统计 · 75 分</h2><span class="small muted">15 + 20×3，证明与计算并重</span></div>
        <div class="topic-grid">${prob.map(topicCard).join('')}</div>
      </section>
      <section class="section">
        <div class="section-head"><h2 class="section-title">年份覆盖 · 2011—2026</h2><span class="small muted">题库已覆盖全部年份</span></div>
        <div class="year-strip">
          ${[...new Set(BANK.map(q => q.year))].sort((a, b) => b - a).map(y => {
            const qs = BANK.filter(q => q.year === y);
            return `<a class="year-cell" href="#/bank?year=${y}"><b>${y}</b><span>${qs.length} 题</span><i>${new Set(qs.map(q => q.topic)).size} 个题型</i></a>`;
          }).join('')}
        </div>
        <p class="small muted" style="margin-top:10px">点击年份直接筛选。2011—2023 题干来自《做题本》文本层；2024—2026 来自真题图片。少数原卷公式缺失的题以“改编”标注补齐。</p>
      </section>
    `;
    scheduleTypeset($('#app'));
  }

  function renderTopic(args) {
    const t = TOPIC_MAP[args[0]];
    if (!t) { $('#app').innerHTML = emptyBox('题型不存在', '请从题型地图重新进入。'); return; }
    const qs = BANK.filter(q => q.topic === t.id);
    const s = topicStats(t.id);
    const related = qs.slice(0, 8);
    const hasCards = CARDS.some(c => c.chapter === t.chapter);
    $('#app').innerHTML = `
      <div class="topic-banner" data-mark="${t.id.toUpperCase()}">
        <div class="eyebrow" style="color:#e5b46a">${esc(t.part)} · ${t.id.toUpperCase()}</div>
        <h1>${esc(t.title)}</h1>
        <p>${esc(t.subtitle)}</p>
        <div class="topic-meta">
          ${chip('考频 ' + t.freq + '/5')}${chip(s.total + ' 道归库真题')}${chip('已做 ' + s.seen)}${chip('正确 ' + s.ok)}
          ${t.years && t.years.length ? chip('出现年份 ' + t.years.join(' / ')) : ''}
        </div>
      </div>

      <div class="two-col">
        <div>
          <div class="card">
            <div class="section-head"><h2 class="section-title">这个题型到底在考什么</h2></div>
            <div class="answer-block">${t.overview || ''}</div>
          </div>

          <div class="card">
            <div class="section-head"><h2 class="section-title">核心公式与结论</h2><span class="small muted">建议先默写，再对照</span></div>
            <div class="formula-grid">
              ${(t.formulas || []).map(f => `<div class="formula"><div class="formula-label">${esc(f.name)}</div>${f.tex}${f.note ? `<div class="tiny muted" style="margin-top:4px">${f.note}</div>` : ''}</div>`).join('')}
            </div>
          </div>

          <div class="card">
            <div class="section-head"><h2 class="section-title">解题策略</h2><span class="small muted">按步骤执行</span></div>
            <ol class="strategy-list">${(t.strategy || []).map(x => `<li>${x}</li>`).join('')}</ol>
          </div>

          <div class="card">
            <div class="section-head"><h2 class="section-title">易错点清单</h2><span class="small muted">考前最后 30 分钟看</span></div>
            <ul class="pitfall-list">${(t.pitfalls || []).map(x => `<li>${x}</li>`).join('')}</ul>
          </div>

          <div class="card">
            <div class="section-head"><h2 class="section-title">对应真题</h2><a class="btn small ghost" href="#/bank?topic=${t.id}">查看全部 ${qs.length} 道 →</a></div>
            <div class="q-list">
              ${related.length ? related.map(q => miniQuestion(q)).join('') : emptyBox('暂无归库真题', '该题型暂无录入，可先看公式与策略。')}
            </div>
          </div>
        </div>

        <aside class="sticky">
          <div class="card">
            <div class="section-head"><h3 class="section-title" style="font-size:18px">掌握度</h3></div>
            <div class="ring" style="--v:${s.pct};width:118px;height:118px;margin:6px auto 10px;background:conic-gradient(var(--accent) calc(var(--v)*1%),var(--paper-3) 0)">
              <div class="ring-in"><b style="font-size:25px;color:var(--ink)">${s.pct}%</b><span style="color:var(--muted)">已做</span></div>
            </div>
            <div class="small muted center">${s.seen} / ${s.total} 道 · 正确 ${s.ok} 道</div>
            <div class="divider"></div>
            <a class="btn accent" style="width:100%" href="#/bank?topic=${t.id}">开始刷这个题型</a>
            ${hasCards
              ? `<a class="btn ghost" style="width:100%;margin-top:7px" href="#/recite?chapter=${encodeURIComponent(t.chapter || '')}">背对应章节</a>`
              : `<a class="btn ghost" style="width:100%;margin-top:7px" href="#/bank?topic=${t.id}">再刷一组真题</a>`}
          </div>
          <div class="card">
            <div class="section-head"><h3 class="section-title" style="font-size:18px">考场时间建议</h3></div>
            <div class="small muted">${t.timeTip || '简答题 8—10 分钟/题；计算题 15—18 分钟/题；先拿稳分，再攻证明。'}</div>
            <div class="divider"></div>
            <div class="small"><b>推荐作答顺序</b><br/>① 会的简答先写关键词<br/>② 计算题写公式再代数<br/>③ 证明题先写结论与关键构造</div>
          </div>
        </aside>
      </div>
    `;
    scheduleTypeset($('#app'));
  }

  function miniQuestion(q) {
    return `<div class="mini-q"><b>${q.year} · ${esc(q.type)} · ${esc(q.title)}</b><p>${q.prompt.replace(/<[^>]+>/g, '').slice(0, 110)}…</p><a class="small" style="color:var(--accent)" href="#/bank?q=${encodeURIComponent(q.title)}">打开解析 →</a></div>`;
  }

  /* ---------------- bank ---------------- */
  let bankFilter = { topic: 'all', year: 'all', type: 'all', status: 'all', q: '' };
  function renderBank(args, query) {
    if (query.topic) bankFilter.topic = query.topic;
    if (query.year) bankFilter.year = query.year;
    if (query.type) bankFilter.type = query.type;
    if (query.status) bankFilter.status = query.status;
    if (query.q) bankFilter.q = query.q;
    const years = [...new Set(BANK.map(q => q.year))].sort((a, b) => b - a);
    const types = [...new Set(BANK.map(q => q.type))];
    $('#app').innerHTML = `
      ${pageHead('QUESTION BANK · 2011—2026', '历年真题库', '按年份、题型、模块、掌握状态筛选。每题含完整解析、关键步骤与易错提醒；先自己在纸上写，再展开对照。题干可跳转原卷核对。', `<a class="btn small" href="#/sources">原卷影像</a><button class="btn small" data-action="toggle-all-answers">展开全部</button><button class="btn" data-action="print">打印当前页</button>`)}
      <div class="note" style="margin-bottom:12px"><b>原文优先：</b>题库是分类练习版，已移除“改编题”；每道题都附「原卷核对」链接。公式、表格、题号以「真题原卷」影像为准。</div>
      <div class="filter-bar">
        <select class="select" id="f-topic">
          <option value="all">全部题型</option>
          ${TOPICS.map(t => `<option value="${t.id}" ${bankFilter.topic === t.id ? 'selected' : ''}>${esc(t.part)} · ${esc(t.title)}</option>`).join('')}
        </select>
        <select class="select" id="f-year">
          <option value="all">全部年份</option>
          ${years.map(y => `<option value="${y}" ${String(bankFilter.year) === String(y) ? 'selected' : ''}>${y}</option>`).join('')}
        </select>
        <select class="select" id="f-type">
          <option value="all">全部题型</option>
          ${types.map(t => `<option value="${t}" ${bankFilter.type === t ? 'selected' : ''}>${esc(t)}</option>`).join('')}
        </select>
        <select class="select" id="f-status">
          <option value="all">全部状态</option>
          <option value="new" ${bankFilter.status === 'new' ? 'selected' : ''}>未做</option>
          <option value="ok" ${bankFilter.status === 'ok' ? 'selected' : ''}>已掌握</option>
          <option value="bad" ${bankFilter.status === 'bad' ? 'selected' : ''}>做错</option>
        </select>
        <input class="input wide" id="f-q" placeholder="关键词：抽样、指数、MLE…" value="${esc(bankFilter.q)}" />
        <button class="btn small primary" data-action="apply-filter">筛选</button>
        <button class="btn small ghost" data-action="clear-filter">清空</button>
        <span class="result-count" id="result-count"></span>
      </div>
      <div class="q-list" id="q-list"></div>
    `;
    renderBankList(query.open === '1');
    const apply = () => {
      bankFilter.topic = $('#f-topic').value; bankFilter.year = $('#f-year').value;
      bankFilter.type = $('#f-type').value; bankFilter.status = $('#f-status').value;
      bankFilter.q = $('#f-q').value.trim(); renderBankList(false);
    };
    ['f-topic', 'f-year', 'f-type', 'f-status'].forEach(id => $('#' + id).addEventListener('change', apply));
    $('#f-q').addEventListener('keydown', e => { if (e.key === 'Enter') apply(); });
    scheduleTypeset($('#app'));
  }

  function filteredBank() {
    const k = bankFilter.q.toLowerCase();
    return BANK.filter(q => {
      if (bankFilter.topic !== 'all' && q.topic !== bankFilter.topic) return false;
      if (bankFilter.year !== 'all' && String(q.year) !== String(bankFilter.year)) return false;
      if (bankFilter.type !== 'all' && q.type !== bankFilter.type) return false;
      const st = state.answers[q.id]?.status || 'new';
      if (bankFilter.status === 'new' && st !== 'new') return false;
      if (bankFilter.status !== 'all' && bankFilter.status !== 'new' && st !== bankFilter.status) return false;
      if (k) {
        const hay = [q.title, q.prompt, q.answer, q.topic, q.year, (q.tags || []).join(' '), TOPIC_MAP[q.topic]?.title].join(' ').toLowerCase();
        if (!hay.includes(k)) return false;
      }
      return true;
    });
  }
  function renderBankList(autoOpen = false) {
    const list = filteredBank();
    const wrap = $('#q-list'); if (!wrap) return;
    $('#result-count').textContent = `共 ${list.length} 道`;
    wrap.innerHTML = list.length ? list.map(q => questionCard(q, autoOpen)).join('') : emptyBox('没有匹配的题', '换一个筛选条件，或清空关键词。');
    scheduleTypeset(wrap);
  }
  function questionCard(q, open = false) {
    const t = TOPIC_MAP[q.topic];
    const st = state.answers[q.id]?.status || 'new';
    const stCls = st === 'ok' ? 'status-ok' : st === 'bad' ? 'status-bad' : st === 'seen' ? 'status-seen' : '';
    return `<article class="q-card ${stCls} ${open ? 'open' : ''}" data-qid="${q.id}">
      <div class="q-head">
        <div class="q-num">${q.year}<br/>${esc(q.type)}</div>
        <div class="q-main">
          <div class="q-title">${esc(q.title)} ${q.marks ? `<span class="pill">${q.marks}分</span>` : ''} ${st === 'ok' ? chip('已掌握', 'ok') : st === 'bad' ? chip('做错', 'bad') : ''}</div>
          <div class="q-prompt">${q.prompt}</div>
          <div class="q-meta">${chip(t ? t.part + ' · ' + t.title : q.topic)}${(q.tags || []).map(x => `<span class="tag">${esc(x)}</span>`).join('')}<a class="tag blue" href="#/source/${q.year}" onclick="event.stopPropagation()">原卷核对 ↗</a></div>
        </div>
        <span class="q-toggle">${open ? '收起解析' : '展开解析'}</span>
      </div>
      <div class="q-body">
        <div class="answer-block">${q.answer}</div>
        <div class="q-actions">
          <button class="btn small" data-action="q-status" data-status="ok" data-qid="${q.id}">✓ 已掌握</button>
          <button class="btn small" data-action="q-status" data-status="bad" data-qid="${q.id}">✗ 做错，回炉</button>
          <button class="btn small ghost" data-action="q-status" data-status="seen" data-qid="${q.id}">标记为已看</button>
          <button class="btn small" data-action="ai-explain" data-qid="${q.id}">AI 精讲</button>
          <span class="spacer"></span>
          <span class="small muted">建议先写步骤，再展开</span>
        </div>
      </div>
    </article>`;
  }

  /* ---------------- drill mode ---------------- */
  let drillState = { key: '', list: [], idx: 0, shown: false };
  function renderDrill(args, query = {}) {
    const params = (args && !Array.isArray(args)) ? args : (query || {});
    const year = params.year || 'all';
    const topic = params.topic || 'all';
    const key = year + '|' + topic;
    if (drillState.key !== key) {
      drillState.list = BANK.filter(q => (year === 'all' || String(q.year) === String(year)) && (topic === 'all' || q.topic === topic));
      drillState.key = key; drillState.idx = 0; drillState.shown = false;
    }
    const list = drillState.list;
    const q = list[drillState.idx];
    const years = [...new Set(BANK.map(x => x.year))].sort((a, b) => b - a);
    $('#app').innerHTML = `
      ${pageHead('DRILL MODE · 一题一题', '逐题刷', '一次只显示一道题：先自己在纸上写，再显示答案；可标记掌握/错题，或让 AI 按标准答案重讲。', `<a class="btn small ghost" href="#/bank">列表模式</a>`)}
      <div class="drill-toolbar">
        <select class="select" id="drill-year">
          <option value="all">全部年份</option>
          ${years.map(y => `<option value="${y}" ${String(year) === String(y) ? 'selected' : ''}>${y}</option>`).join('')}
        </select>
        <select class="select" id="drill-topic">
          <option value="all">全部题型</option>
          ${TOPICS.map(t => `<option value="${t.id}" ${topic === t.id ? 'selected' : ''}>${esc(t.title)}</option>`).join('')}
        </select>
        <span class="spacer"></span><span class="small muted">${list.length ? drillState.idx + 1 : 0} / ${list.length}</span>
      </div>
      ${q ? `<div class="drill-wrap">
        <div class="drill-card">
          <div class="drill-meta"><span>${q.year} · ${esc(q.type)} · ${q.marks || 10} 分</span>${chip(TOPIC_MAP[q.topic]?.title || q.topic)}<a class="tag blue" href="#/source/${q.year}">原卷 ↗</a>${state.answers[q.id]?.status === 'ok' ? chip('已掌握', 'ok') : state.answers[q.id]?.status === 'bad' ? chip('做错', 'bad') : ''}</div>
          <div class="drill-q">${q.prompt}</div>
          ${drillState.shown ? `<div class="drill-a answer-block">${q.answer}</div>` : `<button class="btn primary" data-action="drill-toggle">显示完整答案</button>`}
          <div class="drill-actions">
            <button class="btn small" data-action="drill-prev" ${drillState.idx <= 0 ? 'disabled' : ''}>← 上一题</button>
            <button class="btn small" data-action="drill-next" ${drillState.idx >= list.length - 1 ? 'disabled' : ''}>下一题 →</button>
            <span class="spacer"></span>
            <button class="btn small" data-action="drill-status" data-status="ok" data-qid="${q.id}">✓ 掌握</button>
            <button class="btn small" data-action="drill-status" data-status="bad" data-qid="${q.id}">✗ 做错</button>
            <button class="btn small" data-action="drill-ai" data-qid="${q.id}">AI 精讲</button>
          </div>
        </div>
        <div class="drill-hint small muted">提示：显示答案后，先对照步骤给分，再决定“掌握/做错”。</div>
      </div>` : emptyBox('没有匹配的题', '换一个年份或题型。')}
    `;
    scheduleTypeset($('#app'));
    if ($('#drill-year')) $('#drill-year').onchange = e => { location.hash = '#/drill?year=' + e.target.value + '&topic=' + $('#drill-topic').value; };
    if ($('#drill-topic')) $('#drill-topic').onchange = e => { location.hash = '#/drill?year=' + $('#drill-year').value + '&topic=' + e.target.value; };
  }

  /* ---------------- source papers ---------------- */
  function sourceImages(s) {
    if (s.files) return s.files.map(f => `assets/sources/${f}`);
    return (s.pages || []).map(p => `assets/sources/exam-${String(p).padStart(2, '0')}.jpg`);
  }
  function renderSources() {
    $('#app').innerHTML = `
      ${pageHead('SOURCE PAPERS · 原卷影像', '历年真题原卷', '题干、公式、表格以原卷影像为准。题库中的文字解析用于练习，若与影像不一致，以影像为准。', `<a class="btn" href="#/bank">去题库练习</a>`)}
      <div class="note" style="margin-bottom:18px"><b>为什么保留原卷：</b>2011—2023 年《做题本》的公式/表格是矢量图，文本层会丢公式；2024—2026 为图片版。原卷影像可以逐字核对，避免“改编题”混入。</div>
      <div class="source-grid">
        ${SOURCES.map(s => `<a class="source-card" href="#/source/${s.year}">
          <div class="source-year">${s.year}</div>
          <div class="source-meta">${sourceImages(s).length} 页 · 原卷影像</div>
          <p>${esc(s.note || '')}</p>
          <span class="source-open">查看原卷 →</span>
        </a>`).join('')}
      </div>
    `;
  }
  function renderSource(args) {
    const year = Number(args[0]);
    const s = SOURCES.find(x => x.year === year);
    if (!s) { $('#app').innerHTML = emptyBox('没有这一年的原卷', '请从原卷列表进入。'); return; }
    const imgs = sourceImages(s);
    $('#app').innerHTML = `
      <div class="row" style="margin-bottom:12px"><a class="btn small ghost" href="#/sources">← 返回原卷列表</a><span class="spacer"></span><a class="btn small" href="#/bank?year=${year}">看该年题库</a></div>
      ${pageHead('SOURCE · ' + year, year + ' 年真题原卷', esc(s.note || ''), `<span class="pill">${imgs.length} 页</span>`)}
      <div class="source-pages">
        ${imgs.map((src, i) => `<figure class="source-page"><figcaption>第 ${i + 1} 页 / 共 ${imgs.length} 页</figcaption><a href="${src}" target="_blank" rel="noopener"><img src="${src}" loading="lazy" alt="${year} 年真题第 ${i + 1} 页" /></a></figure>`).join('')}
      </div>
      <div class="note" style="margin-top:18px">点击图片可在新标签页放大查看。原卷为做题本/用户提供图片，水印与页眉属于原文件。</div>
    `;
  }

  /* ---------------- mocks ---------------- */
  function renderMocks() {
    $('#app').innerHTML = `
      ${pageHead('MOCK EXAMS · 3 SETS', '三套趋势模拟卷', '按 2011—2026 真题结构编写：统计学原理 75 分 + 概率论与数理统计 75 分，满分 150，建议 180 分钟。每套都有完整解析与评分建议。', `<a class="btn" href="#/plan">先看复习路线</a>`)}
      <div class="note" style="margin-bottom:18px"><b>怎么用：</b>第一轮按题型刷完后做 A 卷；第二轮错题回炉后做 B 卷；考前 3 周做 C 卷。做题时关掉解析，用答题纸写完整步骤。</div>
      <div class="mock-grid">
        ${MOCKS.map((m, i) => {
          const ms = state.mocks[m.id] || {};
          return `<div class="mock-card">
            <div class="mc-band" style="background:linear-gradient(90deg,${['#bc4b32,#d99a5b','#2f6d68,#7fa89b','#5b4b7a,#a58bb5'][i] || '#bc4b32,#d99a5b'})"></div>
            <div class="row"><span class="pill ${i === 0 ? 'accent' : i === 1 ? 'teal' : 'gold'}">${esc(m.level)}</span><span class="spacer"></span><span class="small muted">${m.time} 分钟</span></div>
            <h3 style="margin-top:9px">${esc(m.title)}</h3>
            <p>${esc(m.subtitle)}</p>
            <div class="mock-meta"><div><b>150</b>满分</div><div><b>10</b>道题</div><div><b>${m.difficulty}</b>难度</div></div>
            <div class="mock-status">
              <span class="small ${ms.submitted ? 'muted' : ''}">${ms.submitted ? '已完成 · 自评 ' + (ms.score ?? '—') + ' 分' : ms.startedAt ? '进行中' : '未开始'}</span>
              <a class="btn small ${ms.submitted ? 'ghost' : 'accent'}" href="#/mock/${m.id}">${ms.submitted ? '重看解析' : ms.startedAt ? '继续作答' : '开始模拟'}</a>
            </div>
          </div>`;
        }).join('')}
      </div>
      <div class="card" style="margin-top:18px">
        <div class="section-head"><h2 class="section-title">模拟卷使用说明</h2></div>
        <div class="grid grid-3">
          <div><b>① 限时</b><p class="small muted">180 分钟，先做统计学原理 75 分，再做概率论。留 10 分钟检查公式与单位。</p></div>
          <div><b>② 自评</b><p class="small muted">交卷后按参考答案给自己打分；计算题按步骤给分，结果错但公式对可给 60%—70%。</p></div>
          <div><b>③ 回炉</b><p class="small muted">低于 105 分：回到题型页补公式；105—125 分：只回炉错题；125 分以上：练速度与书写。</p></div>
        </div>
      </div>
    `;
  }

  let tickHandle = null;
  function renderMock(args) {
    const m = MOCKS.find(x => x.id === args[0]);
    if (!m) { $('#app').innerHTML = emptyBox('模拟卷不存在', '请从模拟卷列表进入。'); return; }
    const ms = state.mocks[m.id] || {};
    if (!ms.startedAt) { ms.startedAt = Date.now(); ms.answers = ms.answers || {}; state.mocks[m.id] = ms; save(); }
    if (!ms.answers) ms.answers = {};
    const totalSec = m.time * 60;
    const elapsed = Math.floor((Date.now() - ms.startedAt) / 1000);
    const remain = totalSec - elapsed;
    const submitted = !!ms.submitted;
    $('#app').innerHTML = `
      <div class="row" style="margin-bottom:12px"><a class="btn small ghost" href="#/mocks">← 返回模拟卷</a><span class="spacer"></span>${submitted ? chip('已交卷 · 可对照解析', 'ok') : chip('作答中 · 自动保存', 'gold')}</div>
      <div class="exam-shell">
        <div class="exam-paper">
          <div class="exam-head">
            <h1>${esc(m.title)}</h1>
            <p>暨南大学 432 统计学 · 模拟卷 · 满分 150 分 · 建议用时 180 分钟</p>
            <p>${esc(m.subtitle)}</p>
          </div>
          ${submitted ? scoreBanner(m) : ''}
          ${m.sections.map((sec, si) => `<section class="exam-section">
            <h2>${esc(sec.name)}（共 ${sec.marks} 分）</h2>
            ${sec.questions.map((q, qi) => {
              const qid = `${m.id}-${si}-${qi}`;
              return `<div class="exam-q" id="${qid}">
                <div class="eq-head"><span>${si + 1}.${qi + 1}</span><div>${q.title} <span class="pill">${q.marks}分</span></div></div>
                <div class="eq-body">${q.prompt}</div>
                ${submitted ? `<div class="answer-block" style="margin-top:10px;border-top:1px dashed var(--line);padding-top:9px"><div class="eyebrow">参考答案</div>${q.answer}</div>` : `<textarea data-mock="${m.id}" data-q="${qid}" placeholder="在这里写关键步骤（自动保存）…">${esc(ms.answers[qid] || '')}</textarea>`}
              </div>`;
            }).join('')}
          </section>`).join('')}
          <div class="row" style="margin-top:18px">
            ${submitted ? `<button class="btn" data-action="reset-mock" data-mid="${m.id}">重做本卷</button>` : `<button class="btn accent" data-action="submit-mock" data-mid="${m.id}">交卷并看解析</button>`}
            <button class="btn ghost" data-action="print">打印</button>
          </div>
        </div>
        <aside class="exam-aside">
          <div class="timer-card">
            <div class="tiny" style="color:#a7a195;letter-spacing:.12em">REMAINING</div>
            <div class="timer ${remain < 900 ? 'warn-time' : ''}" id="mock-timer">${fmtTime(remain)}</div>
            ${bar(Math.max(0, Math.min(100, remain / totalSec * 100)))}
            <div class="small" style="color:#b9b2a5;margin-top:8px">${submitted ? '已交卷，计时停止' : '计时会自动保存；刷新页面不会重置。'}</div>
          </div>
          <div class="card flat" style="padding:13px">
            <div class="small muted" style="margin-bottom:6px">题目导航</div>
            <div class="exam-nav">
              ${m.sections.map((sec, si) => sec.questions.map((q, qi) => `<a href="#${m.id}-${si}-${qi}"><span>${si + 1}.${qi + 1} ${esc(q.title)}</span><b>${q.marks}</b></a>`).join('')).join('')}
            </div>
          </div>
          ${submitted ? `<div class="card flat" style="padding:13px"><div class="small muted">自评得分（0—150）</div><div class="row" style="margin-top:6px"><input class="input" id="self-score" type="number" min="0" max="150" value="${ms.score ?? ''}" style="width:80px"/><button class="btn small" data-action="save-score" data-mid="${m.id}">保存</button></div><div class="small muted" style="margin-top:6px">按步骤给分；结果错但方法对，不要一刀切 0 分。</div></div>` : ''}
        </aside>
      </div>
    `;
    if (!submitted) startTimer(m, totalSec);
    scheduleTypeset($('#app'));
  }
  function scoreBanner(m) {
    const ms = state.mocks[m.id] || {};
    return `<div class="score-banner"><div><b>${ms.score ?? '—'}</b><span> / 150 自评</span></div><div style="flex:1"><b style="font-size:14px;color:#235650">对照解析，按步骤补分</b><div class="small" style="color:#3f6b65">低于 105：回题型页补公式；105—125：回炉错题；125+：练速度与书写。</div></div></div>`;
  }
  function fmtTime(sec) {
    const s = Math.max(0, sec);
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), ss = s % 60;
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(ss).padStart(2, '0')}`;
  }
  function startTimer(m, totalSec) {
    clearInterval(tickHandle);
    const tick = () => {
      const ms = state.mocks[m.id]; if (!ms || ms.submitted) return;
      const left = totalSec - Math.floor((Date.now() - ms.startedAt) / 1000);
      const el = $('#mock-timer'); if (el) {
        el.textContent = left >= 0 ? fmtTime(left) : '+' + fmtTime(-left);
        el.classList.toggle('warn-time', left < 900);
      }
    };
    tick(); tickHandle = setInterval(tick, 1000);
  }

  /* ---------------- recite ---------------- */
  let reciteState = { chapter: 'all', queue: [], idx: 0, flipped: false };
  function buildReciteQueue() {
    let list = CARDS.filter(c => reciteState.chapter === 'all' || c.chapter === reciteState.chapter);
    const due = list.filter(c => { const s = state.cards[c.id]; return !s || (s.due || '') <= today(); });
    const rest = list.filter(c => !due.includes(c));
    reciteState.queue = [...due.sort(() => Math.random() - .5), ...rest.sort(() => Math.random() - .5)];
    reciteState.idx = 0; reciteState.flipped = false;
  }
  function renderRecite(args, query = {}) {
    if (query.chapter) reciteState.chapter = query.chapter;
    const chapters = [...new Set(CARDS.map(c => c.chapter))];
    if (!reciteState.queue.length) buildReciteQueue();
    const c = reciteState.queue[reciteState.idx];
    const cs = cardStats();
    $('#app').innerHTML = `
      ${pageHead('RECITATION · 统计学原理', '原理背诵板块', '卡片的答案来自《专业课背诵》原书 OCR 全文，不再使用概括或自编答案。先看问题，口头复述，再显示完整答案；用「忘了 / 模糊 / 掌握」安排下一轮。', `<a class="btn small" href="#/notes">42 页完整原文</a><button class="btn small" data-action="shuffle-cards">打乱顺序</button>`)}
      <div class="recite-stats">
        <div class="recite-stat"><b>${CARDS.length}</b><span>原文问答卡</span></div>
        <div class="recite-stat"><b>${cs.mastered}</b><span>已掌握</span></div>
        <div class="recite-stat"><b>${cs.due}</b><span>今日到期</span></div>
        <div class="recite-stat"><b>${cs.learning}</b><span>学习中</span></div>
      </div>
      <div class="recite-layout">
        <aside class="chapter-nav">
          <button data-chapter="all" class="${reciteState.chapter === 'all' ? 'active' : ''}">全部章节 <b>${CARDS.length}</b></button>
          ${chapters.map(ch => `<button data-chapter="${esc(ch)}" class="${reciteState.chapter === ch ? 'active' : ''}">${esc(ch)} <b>${CARDS.filter(c => c.chapter === ch).length}</b></button>`).join('')}
        </aside>
        <div>
          ${c ? reciteCardHTML(c) : emptyBox('本章已复习完', '可以切换章节，或稍后再来。')}
        </div>
      </div>
    `;
    scheduleTypeset($('#app'));
  }
  function reciteCardHTML(c) {
    const s = state.cards[c.id] || { level: 0 };
    const idx = reciteState.idx + 1, total = reciteState.queue.length;
    const src = c.page ? `assets/notes/p${String(c.page).padStart(2, '0')}.jpg` : '';
    return `<div class="recite-stage">
      <div class="recite-progress"><span class="small muted">${esc(c.chapter)}</span><span class="spacer"></span><span class="small muted">${idx} / ${total}</span></div>
      ${bar(idx / total * 100)}
      <article class="recite-card">
        <div class="recite-top"><span>第 ${c.num || '—'} 题 · 原文问答</span><span>${dots(Math.min(5, s.level || 0))}</span></div>
        <div class="recite-q">${c.q}</div>
        <div class="recite-meta">${(c.years || []).map(y => chip(y)).join('')}${c.page ? `<a class="tag blue" href="${src}" target="_blank" rel="noopener">原书 p.${c.page} ↗</a>` : ''}</div>
        ${reciteState.flipped
          ? `<div class="recite-answer ocr-text answer-block">${c.a}<a class="source-link" href="${src}" target="_blank" rel="noopener">核对原页 p.${c.page || '—'} ↗</a></div>`
          : `<button class="btn primary" style="align-self:flex-start;margin-top:10px" data-action="toggle-answer">显示完整答案</button>`}
        <div class="recite-actions">
          ${reciteState.flipped ? `<button class="btn" data-action="grade-card" data-grade="0">忘了 · 明天再来</button>
          <button class="btn" data-action="grade-card" data-grade="2">模糊 · 2 天后</button>
          <button class="btn accent" data-action="grade-card" data-grade="4">掌握 · 7 天后</button>` : `<span class="small muted">先回忆，再显示答案；答案完整呈现，不截断。</span>`}
          <span class="spacer"></span>
          <button class="btn small ghost" data-action="toggle-answer">${reciteState.flipped ? '收起答案' : '显示答案'}</button>
        </div>
      </article>
    </div>`;
  }

  /* ---------------- full original notes ---------------- */
  let notesChapter = '';
  function renderNotes(args, query = {}) {
    if (query.chapter) notesChapter = query.chapter;
    if (!notesChapter) notesChapter = NOTES[0]?.title || '';
    const ch = NOTES.find(x => x.title === notesChapter) || NOTES[0];
    const pages = ch ? ch.pages : [];
    $('#app').innerHTML = `
      ${pageHead('ORIGINAL TEXT · 42 PAGES', '背诵原文 · 完整收录', '这是《专业课背诵》统计学原理部分 42 页的 OCR 全文：按章节、按原书顺序排列，未做删减。个别公式/文字受扫描与 OCR 影响，以每页原图为准。', `<a class="btn small" href="#/recite">回到问答卡</a>`)}
      <div class="notes-layout">
        <aside class="chapter-nav">
          ${NOTES.map(x => `<button data-note-chapter="${esc(x.title)}" class="${x.title === ch?.title ? 'active' : ''}">${esc(x.title)} <b>${x.pages.length}</b></button>`).join('')}
        </aside>
        <div class="notes-main">
          <div class="row" style="margin-bottom:8px"><h2 class="section-title">${esc(ch?.title || '')}</h2><span class="spacer"></span><span class="small muted">原书 p.${pages[0] || '—'}—${pages[pages.length - 1] || '—'}</span></div>
          <div class="row" style="margin-bottom:12px">${pages.map(p => `<a class="tag blue" href="assets/notes/p${String(p).padStart(2, '0')}.jpg" target="_blank" rel="noopener">p.${p} ↗</a>`).join('')}</div>
          <div class="raw-text">${esc(ch?.text || '')}</div>
          <div class="note" style="margin-top:16px">原文页影像：${pages.map(p => `<a href="assets/notes/p${String(p).padStart(2, '0')}.jpg" target="_blank" rel="noopener">p.${p}</a>`).join(' · ')}</div>
        </div>
      </div>
    `;
  }
  function renderNotePage(args) {
    const p = Number(args[0]);
    if (!p || p < 1 || p > 56) { $('#app').innerHTML = emptyBox('没有这一页', '页码应在 1—56 之间。'); return; }
    $('#app').innerHTML = `
      <div class="row" style="margin-bottom:12px"><a class="btn small ghost" href="#/notes">← 返回原文</a><span class="spacer"></span><span class="pill">第 ${p} 页</span></div>
      <figure class="source-page"><figcaption>《专业课背诵》第 ${p} 页</figcaption><img src="assets/notes/p${String(p).padStart(2, '0')}.jpg" alt="专业课背诵第 ${p} 页" /></figure>
    `;
  }

  /* ---------------- AI assistant ---------------- */
  const AI_KEY = 'jnu432_ai_v1';
  const AI_DEFAULT = {
    mode: 'proxy',
    proxy: '/api/chat',
    direct: 'https://api.deepseek.com/chat/completions',
    model: 'deepseek-chat',
    key: ''
  };
  let aiState = { messages: [], context: null, busy: false };
  function getAIConfig() {
    try { return { ...AI_DEFAULT, ...(JSON.parse(localStorage.getItem(AI_KEY) || '{}')) }; }
    catch (e) { return { ...AI_DEFAULT }; }
  }
  function saveAIConfig(cfg) { localStorage.setItem(AI_KEY, JSON.stringify(cfg)); }

  function renderAI(args, query = {}) {
    const cfg = getAIConfig();
    let context = aiState.context;
    if (query.q && BANK_MAP[query.q]) context = BANK_MAP[query.q];
    aiState.context = context;
    $('#app').innerHTML = `
      ${pageHead('AI TUTOR · DEEPSEEK', 'AI 助教 · 标准答案生成器', '用你的 DeepSeek API Key，让 AI 按考场标准重写解析、检查步骤或生成同类题。默认走本地 server.py 代理，避免浏览器跨域；也可以直连 API。', `<a class="btn small ghost" href="#/bank">回题库</a>`)}
      <div class="ai-layout">
        <aside class="card ai-config">
          <div class="section-head"><h3 class="section-title" style="font-size:16px">API 设置</h3><span class="pill ${cfg.key ? 'ok' : 'gold'}">${cfg.key ? '已填 Key' : '未填 Key'}</span></div>
          <label class="ai-label">连接方式</label>
          <select class="select" id="ai-mode" style="width:100%">
            <option value="proxy" ${cfg.mode === 'proxy' ? 'selected' : ''}>本地代理 /api/chat（推荐）</option>
            <option value="direct" ${cfg.mode === 'direct' ? 'selected' : ''}>浏览器直连 DeepSeek API</option>
          </select>
          <label class="ai-label">API Key</label>
          <input class="input" id="ai-key" type="password" placeholder="sk-..." value="${esc(cfg.key)}" style="width:100%" />
          <label class="ai-label">模型</label>
          <select class="select" id="ai-model" style="width:100%">
            <option value="deepseek-chat" ${cfg.model === 'deepseek-chat' ? 'selected' : ''}>deepseek-chat</option>
            <option value="deepseek-reasoner" ${cfg.model === 'deepseek-reasoner' ? 'selected' : ''}>deepseek-reasoner</option>
          </select>
          <label class="ai-label">代理地址</label>
          <input class="input" id="ai-proxy" value="${esc(cfg.proxy)}" style="width:100%" />
          <label class="ai-label">直连地址</label>
          <input class="input" id="ai-direct" value="${esc(cfg.direct)}" style="width:100%" />
          <button class="btn primary" style="width:100%;margin-top:10px" data-action="save-ai">保存设置</button>
          <div class="note" style="margin-top:10px;font-size:10.5px">Key 只保存在本机浏览器 localStorage；使用代理时只发送到本机 server.py。公开部署请改用服务端环境变量，不要把 Key 写进代码。</div>
          <div class="divider"></div>
          <div class="small muted">本地代理启动：<br/><code>set DEEPSEEK_API_KEY=sk-...</code><br/><code>python server.py</code></div>
        </aside>
        <section class="card ai-chat">
          <div class="section-head"><h3 class="section-title" style="font-size:16px">对话</h3>${context ? `<span class="pill accent">已带入：${esc(context.year)} · ${esc(context.title)}</span>` : `<span class="pill">未选题</span>`}</div>
          <div class="ai-context">${context ? `<b>当前题目：</b>${context.prompt}<div class="small muted" style="margin-top:4px">参考解析：${esc(String(context.answer || '').replace(/<[^>]+>/g, '').slice(0, 220))}…</div>` : `<span class="small muted">可直接提问，或从题库点「AI 精讲」带入题目。</span>`}</div>
          <div class="ai-messages" id="ai-messages">
            ${aiState.messages.length ? aiState.messages.map(m => `<div class="ai-msg ${m.role}"><div class="ai-role">${m.role === 'user' ? '你' : 'DeepSeek'}</div><div class="ai-body">${esc(m.content)}</div></div>`).join('') : `<div class="empty" style="padding:24px"><b>让 AI 按考场标准讲一遍</b>选择题目后点下方快捷指令，或直接输入问题。</div>`}
          </div>
          <div class="ai-quick">
            <button class="btn small" data-action="ai-quick" data-prompt="请按考场标准答案的格式，逐步完整解答这道题，写出公式、代入、计算和结论，不要只给答案。">标准答案</button>
            <button class="btn small" data-action="ai-quick" data-prompt="请检查我的解题步骤，指出错误、扣分点和补充步骤。">检查步骤</button>
            <button class="btn small" data-action="ai-quick" data-prompt="请换一种更简单的方法讲解这道题，并总结这个题型的通用模板。">换种讲法</button>
            <button class="btn small" data-action="ai-quick" data-prompt="请根据这道题生成一道同考点、同难度的新题，并给出标准答案。">同类题</button>
          </div>
          <div class="ai-input-row">
            <textarea id="ai-input" placeholder="输入你的问题，例如：为什么这里用 t 分布？/ 我的第二步哪里错了？"></textarea>
            <button class="btn primary" data-action="ai-send" ${aiState.busy ? 'disabled' : ''}>${aiState.busy ? '生成中…' : '发送'}</button>
          </div>
        </section>
      </div>
    `;
    scheduleTypeset($('#app'));
  }

  async function sendAI(text) {
    const cfg = getAIConfig();
    if (!cfg.key) { toast('请先在左侧填写 DeepSeek API Key'); return; }
    const content = (text || '').trim();
    if (!content) return;
    const ctx = aiState.context;
    aiState.messages.push({ role: 'user', content });
    aiState.busy = true;
    renderAI();
    const sys = '你是暨南大学432统计学考研辅导老师。回答必须使用中文，按考场标准答案的格式：先写所用公式/定理，再代入数据，再给出计算过程，最后写结论。公式用 LaTeX（$...$ 或 $$...$$）。不要编造数据；如果题目信息不足，明确指出。';
    const contextText = ctx ? `当前题目（${ctx.year}年，${ctx.type}，${TOPIC_MAP[ctx.topic]?.title || ''}）：\n${String(ctx.prompt).replace(/<[^>]+>/g, '')}\n\n站内参考解析（可能简略，仅作参考）：\n${String(ctx.answer).replace(/<[^>]+>/g, '').slice(0, 2500)}` : '当前没有选定题目，请根据用户问题作答。';
    const messages = [
      { role: 'system', content: sys },
      { role: 'system', content: contextText },
      ...aiState.messages.slice(-10).map(m => ({ role: m.role, content: m.content }))
    ];
    const endpoint = cfg.mode === 'direct' ? cfg.direct : cfg.proxy;
    const headers = { 'Content-Type': 'application/json' };
    if (cfg.mode === 'direct') headers['Authorization'] = 'Bearer ' + cfg.key;
    else headers['X-API-Key'] = cfg.key;
    try {
      const res = await fetch(endpoint, { method: 'POST', headers, body: JSON.stringify({ model: cfg.model, messages, temperature: 0.3, stream: false }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error?.message || ('HTTP ' + res.status));
      const answer = data?.choices?.[0]?.message?.content || '（AI 未返回内容）';
      aiState.messages.push({ role: 'assistant', content: answer });
    } catch (e) {
      aiState.messages.push({ role: 'assistant', content: '请求失败：' + e.message + '\n\n请检查：① Key 是否正确；② 是否已启动 server.py；③ 直连模式的 CORS/网络。' });
    } finally {
      aiState.busy = false;
      renderAI();
    }
  }

  /* ---------------- review ---------------- */
  function renderReview() {
    const a = answerStats(), c = cardStats(), m = mockStats();
    const wrong = BANK.filter(q => state.answers[q.id]?.status === 'bad');
    const due = CARDS.filter(cd => { const s = state.cards[cd.id]; return !s || (s.due || '') <= today(); });
    const recent = [...BANK].filter(q => state.answers[q.id]).sort((x, y) => (state.answers[y.id].updated || 0) - (state.answers[x.id].updated || 0)).slice(0, 6);
    $('#app').innerHTML = `
      ${pageHead('REVIEW LOOP · 多轮复习', '错题、到期卡与整卷复盘', '复习不是重复看，而是「检索—反馈—间隔」。这里把到期背诵卡、做错真题、模拟卷得分放在同一个面板。', `<button class="btn small" data-action="export-data">导出进度</button><button class="btn small ghost" data-action="import-data">导入</button>`)}
      <div class="review-grid">
        <div class="review-card"><div class="eyebrow">DUE CARDS</div><div class="big-num">${due.length}</div><h3>今日到期背诵卡</h3><p class="small muted">按 1/2/4/7/15 天间隔排队。</p><a class="btn small accent" style="margin-top:8px" href="#/recite">开始复习</a></div>
        <div class="review-card"><div class="eyebrow">WRONG BOOK</div><div class="big-num">${wrong.length}</div><h3>错题回炉</h3><p class="small muted">做错后标记，二刷时只看错题。</p><a class="btn small" style="margin-top:8px" href="#/bank?status=bad">打开错题本</a></div>
        <div class="review-card"><div class="eyebrow">MOCK</div><div class="big-num">${m.done}/${m.total}</div><h3>模拟卷完成度</h3><p class="small muted">建议 105 分以上再进下一套。</p><a class="btn small" style="margin-top:8px" href="#/mocks">进入模拟</a></div>
      </div>
      <div class="dash-cols">
        <div class="card">
          <div class="section-head"><h2 class="section-title">错题清单</h2><span class="small muted">${wrong.length} 道</span></div>
          ${wrong.length ? wrong.slice(0, 10).map(q => `<div class="wrong-item"><b>${q.year} · ${esc(q.title)}</b><span>${esc(TOPIC_MAP[q.topic]?.title || q.topic)} · 点击回题库重做</span><div><a class="small" style="color:var(--accent)" href="#/bank?q=${encodeURIComponent(q.title)}">打开题目 →</a></div></div>`).join('') : emptyBox('还没有错题', '做错的题会自动进入这里。')}
        </div>
        <div class="card">
          <div class="section-head"><h2 class="section-title">最近学习</h2><span class="small muted">按时间倒序</span></div>
          ${recent.length ? recent.map(q => `<div class="wrong-item"><b>${q.year} · ${esc(q.title)}</b><span>${state.answers[q.id].status === 'ok' ? '已掌握' : state.answers[q.id].status === 'bad' ? '做错' : '已看'} · ${new Date(state.answers[q.id].updated || Date.now()).toLocaleDateString('zh-CN')}</span></div>`).join('') : emptyBox('还没有记录', '从真题库开始第一道题。')}
          <div class="divider"></div>
          <div class="row"><button class="btn small ghost" data-action="reset-data">清空全部进度</button></div>
        </div>
      </div>
      <div class="card" style="margin-top:16px">
        <div class="section-head"><h2 class="section-title">三轮复习检查表</h2><span class="small muted">点击保存</span></div>
        <ul class="checklist">
          ${[
            ['r1a', '一轮：看完 11 个统计学原理题型页 + 20 个概率题型页'],
            ['r1b', '一轮：背诵卡过完一遍，能复述 80% 的简答题关键词'],
            ['r2a', '二轮：按题型刷完 2011—2023 真题，错题全部标记'],
            ['r2b', '二轮：2024—2026 真题限时重做，重点看新题型'],
            ['r3a', '三轮：A 卷限时 180 分钟，自评并回炉'],
            ['r3b', '三轮：B/C 卷至少完成一套，训练时间分配'],
            ['r3c', '考前：公式速查 + 易错点清单 + 错题本三刷']
          ].map(([id, txt]) => `<li><input type="checkbox" data-plan="${id}" ${state.plan[id] ? 'checked' : ''}/><span>${txt}</span></li>`).join('')}
        </ul>
      </div>
    `;
  }

  /* ---------------- plan ---------------- */
  function renderPlan() {
    const a = answerStats(), c = cardStats(), m = mockStats();
    const days = Math.max(0, Math.ceil((new Date(state.examDate + 'T00:00:00') - new Date()) / 86400000));
    $('#app').innerHTML = `
      ${pageHead('STUDY PLAN · 三轮复习', '把 150 分拆成可执行的周计划', '以「题型—真题—整卷」为主线。默认按 8 周设计；你可以按剩余天数压缩或拉长。', `<button class="btn small" data-action="set-exam-date">设置初试日期</button>`)}
      <div class="hero" style="padding:24px 28px;margin-bottom:18px">
        <div class="row" style="position:relative;z-index:1;justify-content:space-between;align-items:flex-end">
          <div><div class="eyebrow" style="color:#e5b46a">COUNTDOWN</div><h2 style="font-size:26px;margin:4px 0">距离初试还有 <em style="color:#e5b46a">${days}</em> 天</h2><p style="margin:0;color:#c8c1b4">当前：真题 ${pct(a.seen,a.total)}% · 背诵 ${pct(c.mastered,c.total)}% · 模拟 ${m.done}/${m.total}</p></div>
          <div class="row"><span class="pill" style="background:rgba(255,255,255,.1);border-color:rgba(255,255,255,.2);color:#fff">初试 ${state.examDate}</span></div>
        </div>
      </div>
      <div class="grid grid-2">
        <div class="card">
          <div class="section-head"><h2 class="section-title">阶段一 · 基础建网（约 3 周）</h2><span class="pill accent">现在</span></div>
          <div class="timeline">
            <div class="tl-item"><h3>Week 1：统计描述 + 抽样</h3><p>题型 st01—st07；背诵第 1—6 章；每天 15 张卡 + 3 道真题。</p></div>
            <div class="tl-item"><h3>Week 2：相关回归 + 时间数列 + 指数</h3><p>题型 st08—st11；把公式写成一张 A4 速查表。</p></div>
            <div class="tl-item"><h3>Week 3：概率论主干</h3><p>pr01—pr05；重点练二维随机变量与数字特征。</p></div>
          </div>
        </div>
        <div class="card">
          <div class="section-head"><h2 class="section-title">阶段二 · 真题归类（约 3 周）</h2><span class="pill teal">强化</span></div>
          <div class="timeline">
            <div class="tl-item"><h3>按题型刷 2011—2019</h3><p>每天 2 个题型；错题标记，不追求速度，追求步骤完整。</p></div>
            <div class="tl-item"><h3>2020—2023 限时套刷</h3><p>每套 75 分钟统计 + 75 分钟概率；训练书写与单位。</p></div>
            <div class="tl-item"><h3>2024—2026 新题复盘</h3><p>重点看回归表格、指数体系、抽样组织方式的新问法。</p></div>
          </div>
        </div>
        <div class="card">
          <div class="section-head"><h2 class="section-title">阶段三 · 整卷模拟（约 2 周）</h2><span class="pill gold">冲刺</span></div>
          <div class="timeline">
            <div class="tl-item"><h3>A 卷：基础稳固</h3><p>目标 105+；交卷后按题型统计失分。</p></div>
            <div class="tl-item"><h3>B 卷：计算强化</h3><p>目标 115+；重点练指数、抽样、回归。</p></div>
            <div class="tl-item"><h3>C 卷：综合冲刺</h3><p>目标 125+；控制时间，先拿稳分。</p></div>
          </div>
        </div>
        <div class="card">
          <div class="section-head"><h2 class="section-title">每日节奏（可复制）</h2></div>
          <ul class="checklist">
            ${['20 张背诵卡（先回忆后翻面）', '3—5 道真题（按题型，写完整步骤）', '10 分钟公式默写', '5 分钟错题回炉', '睡前 3 分钟口述今天学的 3 个概念'].map((x, i) => `<li><input type="checkbox" data-plan="daily${i}" ${state.plan['daily' + i] ? 'checked' : ''}/><span>${x}</span></li>`).join('')}
          </ul>
          <div class="divider"></div>
          <div class="small muted">建议把「背诵」放在早上，「真题」放在整块时间，「错题」放在晚上。</div>
        </div>
      </div>
    `;
  }

  /* ---------------- account ---------------- */
  function renderAccount() {
    const statusText = cloudStatus === 'synced' ? '已同步' : cloudStatus === 'syncing' ? '同步中…' : cloudStatus === 'error' ? '同步失败' : '仅保存在本机';
    $('#app').innerHTML = `
      ${pageHead('ACCOUNT · 跨设备同步', '账号与同步', '登录后，做题、背诵、模拟卷进度会保存到服务器；手机、电脑、平板登录同一账号即可继续。', `<a class="btn small ghost" href="#/review">看复习进度</a>`)}
      <div class="account-layout">
        <div class="card">
          ${currentUser ? `
            <div class="row"><div class="account-avatar">${esc(currentUser.email[0].toUpperCase())}</div><div><h2 style="font-size:18px">${esc(currentUser.email)}</h2><div class="small muted">已登录 · ${statusText}</div></div></div>
            <div class="divider"></div>
            <div class="note">你的进度会在这个账号下同步。换设备时用同一邮箱登录即可拉取。</div>
            <div class="row" style="margin-top:14px">
              <button class="btn primary" data-action="account-sync">立即同步</button>
              <button class="btn" data-action="account-logout">退出登录</button>
            </div>
            <div class="small muted" style="margin-top:12px">${cloudStatus === 'error' ? '上次同步失败，请检查网络或重新登录。' : '自动同步：每次做题/背诵/模拟卷保存后约 1 秒上传。'}</div>
          ` : `
            <div class="eyebrow">SIGN IN</div>
            <h2 style="font-size:21px;margin-bottom:4px">登录 / 注册</h2>
            <p class="small muted">用邮箱创建账号，进度会跟账号走，不再只存在本机浏览器。</p>
            <label class="ai-label">邮箱</label>
            <input class="input" id="auth-email" type="email" placeholder="you@example.com" style="width:100%" autocomplete="email" />
            <label class="ai-label">密码</label>
            <input class="input" id="auth-password" type="password" placeholder="至少 6 位" style="width:100%" autocomplete="current-password" />
            <div class="row" style="margin-top:12px">
              <button class="btn primary" data-action="account-login">登录</button>
              <button class="btn" data-action="account-register">注册新账号</button>
            </div>
            <div class="note" style="margin-top:12px">这是本机 <code>server.py</code> 提供的账号系统；部署到公网后同一套接口仍可用。忘记密码暂不支持自助找回，请重新注册。</div>
          `}
        </div>
        <div class="card">
          <div class="section-head"><h3 class="section-title" style="font-size:16px">同步什么</h3></div>
          <ul class="checklist">
            <li><span>✓ 每题掌握 / 做错状态、错题本</span></li>
            <li><span>✓ 背诵卡熟练度与下次复习日期</span></li>
            <li><span>✓ 模拟卷自评分数与作答草稿</span></li>
            <li><span>✓ 三轮检查表、学习打卡记录</span></li>
          </ul>
          <div class="divider"></div>
          <div class="small muted">不同步：AI API Key（只存本机浏览器）、页面偏好主题。换设备后重新填 Key 即可。</div>
        </div>
      </div>
    `;
  }

  /* ---------------- search ---------------- */
  function renderSearch(args, query) {
    const q = (query.q || '').trim();
    const k = q.toLowerCase();
    const qs = k ? BANK.filter(x => [x.title, x.prompt, x.answer, x.year, (x.tags || []).join(' ')].join(' ').toLowerCase().includes(k)) : [];
    const cs = k ? CARDS.filter(x => [x.q, x.a, x.chapter, (x.years || []).join(' ')].join(' ').toLowerCase().includes(k)) : [];
    const ts = k ? TOPICS.filter(x => [x.title, x.subtitle, x.overview].join(' ').toLowerCase().includes(k)) : [];
    $('#app').innerHTML = `
      ${pageHead('SEARCH', `搜索：${esc(q || '（空）')}`, `真题 ${qs.length} · 背诵卡 ${cs.length} · 题型 ${ts.length}`)}
      ${!k ? emptyBox('输入关键词开始搜索', '例如：抽样、指数、MLE、拒绝域、回归。') : ''}
      ${ts.length ? `<div class="card"><div class="section-head"><h2 class="section-title">题型</h2></div>${ts.map(t => `<div class="mini-q"><b>${esc(t.title)}</b><p>${esc(t.subtitle)}</p><a class="small" style="color:var(--accent)" href="#/topic/${t.id}">打开题型 →</a></div>`).join('')}</div>` : ''}
      ${qs.length ? `<div class="card" style="margin-top:14px"><div class="section-head"><h2 class="section-title">真题</h2></div><div class="q-list">${qs.slice(0, 20).map(q => questionCard(q)).join('')}</div></div>` : ''}
      ${cs.length ? `<div class="card" style="margin-top:14px"><div class="section-head"><h2 class="section-title">背诵卡</h2></div>${cs.slice(0, 20).map(c => `<div class="mini-q"><b>${esc(c.q)}</b><p>${esc(c.chapter)}</p><a class="small" style="color:var(--accent)" href="#/recite?chapter=${encodeURIComponent(c.chapter)}">去背诵 →</a></div>`).join('')}</div>` : ''}
    `;
    scheduleTypeset($('#app'));
  }

  /* ---------------- global events ---------------- */
  document.addEventListener('click', async (e) => {
    const actionEl = e.target.closest('[data-action]');
    const nav = e.target.closest('[data-nav]');
    if (nav) { $('#sidebar')?.classList.remove('open'); }

    if (actionEl) {
      const act = actionEl.dataset.action;
      if (act === 'print') { e.preventDefault(); window.print(); return; }
      if (act === 'toggle-all-answers') {
        const cards = $$('.q-card');
        const anyClosed = cards.some(c => !c.classList.contains('open'));
        cards.forEach(c => {
          c.classList.toggle('open', anyClosed);
          const t = c.querySelector('.q-toggle'); if (t) t.textContent = anyClosed ? '收起解析' : '展开解析';
        });
        actionEl.textContent = anyClosed ? '收起全部' : '展开全部';
        if (anyClosed) scheduleTypeset($('#app'));
        return;
      }
      if (act === 'apply-filter') { e.preventDefault(); $('#f-q')?.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter' })); return; }
      if (act === 'clear-filter') { bankFilter = { topic: 'all', year: 'all', type: 'all', status: 'all', q: '' }; location.hash = '#/bank'; if (location.hash === '#/bank') renderBank([], {}); return; }
      if (act === 'ai-explain') {
        e.preventDefault(); e.stopPropagation();
        location.hash = '#/ai?q=' + encodeURIComponent(actionEl.dataset.qid);
        return;
      }
      if (act === 'save-ai') {
        const cfg = {
          mode: $('#ai-mode').value, key: $('#ai-key').value.trim(),
          model: $('#ai-model').value, proxy: $('#ai-proxy').value.trim(),
          direct: $('#ai-direct').value.trim()
        };
        saveAIConfig(cfg); toast('AI 设置已保存'); renderAI(); return;
      }
      if (act === 'ai-send') {
        const input = $('#ai-input');
        sendAI(input ? input.value : ''); return;
      }
      if (act === 'ai-quick') { sendAI(actionEl.dataset.prompt || ''); return; }
      if (act === 'drill-toggle') { drillState.shown = !drillState.shown; renderDrill({ year: drillState.key.split('|')[0], topic: drillState.key.split('|')[1] }); return; }
      if (act === 'drill-prev') { drillState.idx = Math.max(0, drillState.idx - 1); drillState.shown = false; renderDrill({ year: drillState.key.split('|')[0], topic: drillState.key.split('|')[1] }); return; }
      if (act === 'drill-next') { drillState.idx = Math.min(drillState.list.length - 1, drillState.idx + 1); drillState.shown = false; renderDrill({ year: drillState.key.split('|')[0], topic: drillState.key.split('|')[1] }); return; }
      if (act === 'drill-status') {
        const qid = actionEl.dataset.qid, status = actionEl.dataset.status;
        state.answers[qid] = { status, updated: Date.now() }; touchHistory(); save(); renderDrill({ year: drillState.key.split('|')[0], topic: drillState.key.split('|')[1] }); toast(status === 'ok' ? '已标记掌握' : '已加入错题'); return;
      }
      if (act === 'drill-ai') { location.hash = '#/ai?q=' + encodeURIComponent(actionEl.dataset.qid); return; }
      if (act === 'account-login' || act === 'account-register') {
        const email = ($('#auth-email')?.value || '').trim();
        const password = $('#auth-password')?.value || '';
        if (!email || !password) { toast('请输入邮箱和密码'); return; }
        try {
          const data = await api(act === 'account-login' ? '/api/login' : '/api/register', {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password })
          });
          setToken(data.token); currentUser = data.user; updateAccountChip();
          if (act === 'account-login') { await pullCloud(); toast('登录成功，已拉取云端进度'); }
          else { await pushCloud(); toast('注册成功，已上传本机进度'); }
          renderAccount();
        } catch (e) { toast(e.message); }
        return;
      }
      if (act === 'account-logout') {
        try { await api('/api/logout', { method: 'POST' }); } catch (e) {}
        setToken(''); currentUser = null; cloudStatus = 'local'; updateAccountChip(); renderAccount(); toast('已退出登录，本地进度仍保留'); return;
      }
      if (act === 'account-sync') {
        await pushCloud();
        if (cloudStatus === 'synced') toast('已同步到云端');
        else toast('同步失败，请检查网络');
        renderAccount(); return;
      }
      if (act === 'q-status') {
        e.preventDefault(); e.stopPropagation();
        const qid = actionEl.dataset.qid, status = actionEl.dataset.status;
        state.answers[qid] = { status, updated: Date.now() };
        touchHistory(); save();
        const card = actionEl.closest('.q-card');
        card.classList.remove('status-ok', 'status-bad', 'status-seen');
        card.classList.add(status === 'ok' ? 'status-ok' : status === 'bad' ? 'status-bad' : 'status-seen');
        toast(status === 'ok' ? '已标记掌握' : status === 'bad' ? '已加入错题本' : '已标记为看过');
        renderBankList();
        return;
      }
      if (act === 'toggle-answer') {
        reciteState.flipped = !reciteState.flipped;
        renderRecite();
        return;
      }
      if (act === 'grade-card') {
        const c = reciteState.queue[reciteState.idx]; if (!c) return;
        const g = Number(actionEl.dataset.grade);
        const old = state.cards[c.id] || { level: 0 };
        const level = g === 0 ? Math.max(0, (old.level || 0) - 1) : g === 4 ? Math.min(5, (old.level || 0) + 1) : Math.max(1, old.level || 1);
        const delay = g === 0 ? 1 : g === 4 ? 7 : 2;
        state.cards[c.id] = { level, due: addDays(delay), last: Date.now(), seen: (old.seen || 0) + 1 };
        touchHistory(); save();
        reciteState.idx++;
        reciteState.flipped = false;
        if (reciteState.idx >= reciteState.queue.length) {
          buildReciteQueue();
          toast('本轮完成，已按记忆强度重新排队');
        }
        renderRecite();
        return;
      }
      if (act === 'shuffle-cards') { buildReciteQueue(); renderRecite(); toast('已打乱顺序'); return; }
      if (act === 'submit-mock') {
        const mid = actionEl.dataset.mid; const ms = state.mocks[mid] || {};
        ms.submitted = true; ms.submittedAt = Date.now(); state.mocks[mid] = ms; touchHistory(); save();
        clearInterval(tickHandle); renderMock([mid], {}); toast('已交卷，开始对照解析'); return;
      }
      if (act === 'reset-mock') {
        const mid = actionEl.dataset.mid;
        state.mocks[mid] = { startedAt: Date.now(), answers: {}, submitted: false };
        save(); renderMock([mid], {}); toast('已重置本卷'); return;
      }
      if (act === 'save-score') {
        const mid = actionEl.dataset.mid; const v = Number($('#self-score')?.value || 0);
        if (state.mocks[mid]) state.mocks[mid].score = Math.max(0, Math.min(150, v));
        save(); renderMock([mid], {}); toast('自评分数已保存'); return;
      }
      if (act === 'set-exam-date') {
        const v = prompt('输入初试日期（YYYY-MM-DD）：', state.examDate);
        if (v && /^\d{4}-\d{2}-\d{2}$/.test(v)) { state.examDate = v; save(); renderPlan(); }
        return;
      }
      if (act === 'export-data') {
        const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
        const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
        a.download = `jnu432-progress-${today()}.json`; a.click(); URL.revokeObjectURL(a.href); toast('进度已导出'); return;
      }
      if (act === 'import-data') {
        const input = document.createElement('input'); input.type = 'file'; input.accept = '.json';
        input.onchange = () => {
          const f = input.files[0]; if (!f) return;
          const reader = new FileReader();
          reader.onload = () => { try { const d = JSON.parse(reader.result); state = { ...DEFAULT_STATE, ...d }; save(); route(); toast('进度已导入'); } catch (err) { toast('文件格式不正确'); } };
          reader.readAsText(f);
        };
        input.click(); return;
      }
      if (act === 'reset-data') {
        if (confirm('确定清空全部做题、背诵、模拟卷进度？此操作不可撤销。')) { state = { ...DEFAULT_STATE }; save(); route(); toast('已清空'); }
        return;
      }
    }

    // question card toggle
    const head = e.target.closest('.q-head');
    if (head && !e.target.closest('[data-action]')) {
      const card = head.closest('.q-card');
      const open = card.classList.toggle('open');
      const t = card.querySelector('.q-toggle'); if (t) t.textContent = open ? '收起解析' : '展开解析';
      if (open) {
        const qid = card.dataset.qid;
        if (!state.answers[qid]) { state.answers[qid] = { status: 'seen', updated: Date.now() }; touchHistory(); save(); }
        scheduleTypeset(card);
      }
      return;
    }

    // recite chapter buttons
    const chBtn = e.target.closest('[data-chapter]');
    if (chBtn) {
      reciteState.chapter = chBtn.dataset.chapter;
      buildReciteQueue(); renderRecite(); return;
    }
    const noteBtn = e.target.closest('[data-note-chapter]');
    if (noteBtn) {
      notesChapter = noteBtn.dataset.noteChapter;
      renderNotes(); return;
    }
  });

  document.addEventListener('change', (e) => {
    const plan = e.target.closest('[data-plan]');
    if (plan) { state.plan[plan.dataset.plan] = plan.checked; touchHistory(); save(); }
  });
  document.addEventListener('input', (e) => {
    const ta = e.target.closest('textarea[data-mock]');
    if (ta) {
      const mid = ta.dataset.mock, qid = ta.dataset.q;
      if (!state.mocks[mid]) state.mocks[mid] = { startedAt: Date.now(), answers: {}, submitted: false };
      state.mocks[mid].answers[qid] = ta.value;
      clearTimeout(ta._t); ta._t = setTimeout(save, 350);
    }
  });

  // sidebar menu
  $('#menu-btn')?.addEventListener('click', () => $('#sidebar')?.classList.toggle('open'));
  document.addEventListener('click', async (e) => {
    if (window.innerWidth > 900) return;
    if (!e.target.closest('#sidebar') && !e.target.closest('#menu-btn')) $('#sidebar')?.classList.remove('open');
  });

  // theme
  function applyTheme() {
    document.documentElement.dataset.theme = state.theme;
    document.body.classList.toggle('dark', state.theme === 'dark');
    const btn = $('#theme-toggle'); if (btn) btn.textContent = state.theme === 'dark' ? '☀ 切换浅色' : '◐ 切换深色';
  }
  $('#theme-toggle')?.addEventListener('click', () => { state.theme = state.theme === 'dark' ? 'light' : 'dark'; save(); applyTheme(); });
  applyTheme();

  // quick review
  $('#quick-review')?.addEventListener('click', () => { location.hash = '#/review'; });

  // global search
  const search = $('#global-search');
  search?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { const q = search.value.trim(); if (q) location.hash = '#/search?q=' + encodeURIComponent(q); }
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === '/' && document.activeElement !== search && !/INPUT|TEXTAREA/.test(document.activeElement.tagName)) { e.preventDefault(); search?.focus(); }
    if (e.key === 'Escape') { $('#sidebar')?.classList.remove('open'); }
  });

  // init
  applyTheme();
  updateSideProgress();
  updateAccountChip();
  if (!location.hash) location.hash = '#/';
  route();
  initCloud();

  if (location.search.includes('debug=1')) {
    setTimeout(() => {
      const nav = $('.mobile-nav'), hero = $('.hero'), stat = $('.stat-card');
      document.title = JSON.stringify({
        inner: window.innerWidth, scroll: document.documentElement.scrollWidth,
        body: document.body.getBoundingClientRect().width,
        nav: nav ? nav.getBoundingClientRect().width : null,
        hero: hero ? hero.getBoundingClientRect().width : null,
        stat: stat ? stat.getBoundingClientRect().width : null,
        navLinks: nav ? nav.children.length : null
      });
    }, 1200);
  }
})();



